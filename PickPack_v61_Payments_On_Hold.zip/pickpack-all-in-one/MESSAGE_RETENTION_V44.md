# PickPack v44: 30-day message visibility

Delivery messages are returned only when their `createdAt` is within the past 30 days. Completed or canceled deliveries last updated more than 30 days ago are hidden from the Messages listing. Active delivery conversations remain available, but messages older than 30 days are not returned. These restrictions are checked server-side in `/api/delivery-messages`. Admin monitoring follows the same 30-day visibility window.

**Important:** This release hides messages older than 30 days; it does not physically delete database rows. Do not represent this as automatic deletion. A scheduled retention job with incident/legal-hold exclusions is required before enabling physical deletion. Existing access restrictions still apply. Direct admin-to-driver messaging and separate Dispatch Admin roles are not yet included.
