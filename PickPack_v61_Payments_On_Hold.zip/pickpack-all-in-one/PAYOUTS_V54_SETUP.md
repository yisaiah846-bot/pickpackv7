# PickPack v54 — website payout setup

Drivers: sign in at /driver and open /driver/payouts. With STRIPE_CONNECT_ENABLED=true and a valid Stripe test secret key, the Connect Bank Account button creates a Stripe Express account and redirects to Stripe-hosted onboarding. Stripe handles bank details and identity checks. After returning, refresh status.

Super Admin: open /admin/payments and follow the link to Stripe's business payout settings to connect the company's bank account securely.

Run `npm install`, `npx prisma db push`, `npx prisma generate`, `npm run build`. Back up the database before schema changes. Keep real payments disabled.

This is onboarding only, NOT automated transfers, driver payouts, charge reconciliation, refunds, or real customer billing. Stripe Connect account capabilities and regional requirements vary. Only activate live keys after provider approval, compliance review, and end-to-end testing. No bank numbers or Stripe secret keys should be entered into PickPack UI or shared in chat.
