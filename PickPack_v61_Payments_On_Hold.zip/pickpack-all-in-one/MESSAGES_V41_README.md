# PickPack v41 — Messages navigation

Added Messages to global navigation and `/messages` landing page. Links connect to existing `/support` ticket flow and `/admin#support` for authenticated admins. This update does not add direct messages or staff-to-staff chat.
