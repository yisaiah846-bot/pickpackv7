# PickPack Operations v6 — Tested source changes, not production ready

Adds persisted customer support requests and admin replies, a monthly payment-status-based summary, and a server-verified admin promotion endpoint. Existing v5 auto-demo dispatch remains.

## Install
1. Back up the database and existing site. Preserve your `.env` and never upload secrets.
2. Extract over a copy of the project.
3. `npm.cmd install`
4. `npx.cmd prisma validate`
5. `npx.cmd prisma generate`
6. `npx.cmd prisma db push` (stop if warned of destructive changes)
7. `npm.cmd run dev`
8. Visit `/support` as a customer and `/admin` as admin.

## Critical limitations
- AI customer support, live GPS, maps, address autocomplete, Stripe and real driver vetting are NOT implemented. No real deliveries or charges.
- Admin promotion API requires both the current admin's TOTP code and an already enrolled TOTP secret for the target. There is not yet a self-service TOTP enrollment UI for customers, so promotions require a secure enrollment workflow before use. Do not write secrets to screenshots/logs.
- Revenue figures are based on database payment status, not reconciled Stripe transactions. Demo orders should remain unpaid.
- Driver approval is still demo-only and does not verify identity, insurance, or driving eligibility.
- Keep demo mode out of production and test against a disposable database.
