# PickPack v59 login troubleshooting

This update repairs the admin MFA 6-digit regex and improves the database error diagnostics. Login now fetches only required user columns, avoiding unrelated newer profile/banking columns during authentication.

If you see "database schema out of date", back up PostgreSQL first, then:
1. Stop Next.js.
2. npm install
3. npx prisma db push
4. npx prisma generate
5. npm run dev

Do not run prisma db push --force-reset; it can delete existing customer, driver, and admin records.

Existing customers remain exempt from email verification. Driver role checks and admin authenticator MFA remain enforced. No role or password changes are made.

If an error remains, check the terminal where npm run dev is running. Do not share passwords, tokens or .env secrets.
