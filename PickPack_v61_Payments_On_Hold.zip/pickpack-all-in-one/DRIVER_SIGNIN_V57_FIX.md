# PickPack v57 — Driver sign-in guidance

If an account belongs to CUSTOMER or ADMIN, the Driver portal explains the account type and links to the appropriate portal. It does not automatically convert accounts or bypass approval.

To become a driver, sign in with your customer account at /login, then visit /become-driver and submit an application. Only an approved driver account can use /driver/login.

Customer email verification remains disabled as in v56. No database migration is needed.

Run npm.cmd install, npx.cmd prisma generate, npm.cmd run dev.
