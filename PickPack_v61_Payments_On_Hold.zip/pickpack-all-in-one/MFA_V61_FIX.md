# PickPack v61 — Admin MFA validation fix

Corrected an escaped regular expression that rejected valid six-digit authenticator codes before TOTP validation. Also corrected numeric-only input sanitization. Existing MFA secrets and accounts are unchanged.

Admin MFA remains required. If codes still fail after this fix, check Windows automatic time synchronization and the authenticator pairing. Never share authenticator codes or secrets.

Install: stop the server; replace the project files; run `npm.cmd install`, `npx.cmd prisma generate`, `npm.cmd run dev`.

This update does not fix unrelated PostgreSQL P1000 credential failures. The archive was integrity checked, not fully build-tested.
