# PickPack v56 — Customer email verification removed

Customer signup now creates a customer account without sending an email verification code, and signs the customer in directly. Existing customer accounts that previously required email verification can sign in using their correct password without a code. No database migration is required.

Admin MFA and non-customer verification gates are unchanged. Existing verification endpoints are retained for compatibility but are not used in customer signup/login.

Security note: Customer email addresses are now unverified. This increases the risk of mistyped, fraudulent, or impersonated addresses. Do not use email ownership as proof of identity, and reconsider verification before launching real payments or sensitive customer workflows.

Install: replace project, npm install, npx prisma generate, npm run dev.
