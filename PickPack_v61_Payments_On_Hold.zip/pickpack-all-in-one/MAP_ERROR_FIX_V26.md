# Driver map response handling — v26
- The driver dashboard now reads the tracking API response as text before parsing, preventing the browser's raw `Unexpected end of JSON input` error.
- Empty/error responses display an actionable tracking-service error instead of an uncaught parsing exception.
- GPS sharing is automatic while an assigned delivery is active, subject to browser permission. There are no manual Stop/Resume GPS controls.
- Simulated delivery progress, cancellation and reassignment remain unchanged.

Note: If the server returns HTTP 500 or an empty body, check its terminal logs and database connectivity; this client-side patch cannot repair a failed backend service.
