import Link from "next/link";
export default function ProfileMenu({role}:{role:string}) {
 return <Link href="/profile" aria-label="Open your profile" className="ghost" style={{marginLeft:"auto",color:"#d4af37",border:"1px solid #d4af37",display:"inline-flex",alignItems:"center",gap:8,padding:"10px 16px",borderRadius:9,textDecoration:"none"}}><svg aria-hidden="true" width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="9" r="3"/><path d="M5.6 19a7 7 0 0 1 12.8 0"/></svg><span>Profile</span></Link>;
}
