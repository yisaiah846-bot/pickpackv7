"use client";
import {useState} from "react";
export default function PortalLogin({portal}:{portal:"ADMIN"|"DRIVER"|"CUSTOMER"}){
 const [correctPath,setCorrectPath]=useState<string|null>(null);
 const [email,setEmail]=useState(""),[password,setPassword]=useState(""),[mfa,setMfa]=useState(""),[name,setName]=useState("");
 const [register,setRegister]=useState(false),[error,setError]=useState(""),[busy,setBusy]=useState(false);
 async function submit(e:React.FormEvent){
  e.preventDefault();if(busy)return;setBusy(true);setError("");setCorrectPath(null);
  try{
   const response=await fetch(register?"/api/auth/register":"/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:email.trim(),password,mfa,name,portal}),cache:"no-store"});
   const raw=await response.text();let result:any;
   try{result=JSON.parse(raw)}catch{throw new Error("The sign-in server returned an invalid response. Check your server terminal.")}
   if(!response.ok){if(typeof result.correctPath==="string")setCorrectPath(result.correctPath);throw new Error(result.error||"Sign in failed");}
   window.location.assign(result.redirectTo|| (register?"/dashboard":portal==="ADMIN"?"/admin":portal==="DRIVER"?"/driver":"/dashboard"));
  }catch(e){setError(e instanceof Error?e.message:"Sign in failed")}finally{setBusy(false)}
 }
 return <main className="wrap"><div className="card" style={{maxWidth:480,margin:"auto"}}>
  <span className="pill">PICKPACK · {portal} ACCESS</span>
  <h1>{register?"Create customer account":portal==="ADMIN"?"Admin sign in":portal==="DRIVER"?"Driver sign in":"Customer sign in"}</h1>
  <form onSubmit={submit}>
   {register&&<><label htmlFor="register-name">Name</label><input id="register-name" required value={name} onChange={e=>setName(e.target.value)} autoComplete="name"/></>}
   <label htmlFor="login-email">Email</label><input id="login-email" required type="email" value={email} onChange={e=>setEmail(e.target.value)} autoComplete="email"/>
   <label htmlFor="login-password">Password</label><input id="login-password" required type="password" minLength={register?10:1} value={password} onChange={e=>setPassword(e.target.value)} autoComplete={register?"new-password":"current-password"}/>
   {portal==="ADMIN"&&!register&&<><label htmlFor="login-mfa">Authenticator code</label><input id="login-mfa" required inputMode="numeric" pattern="[0-9]{6}" maxLength={6} value={mfa} onChange={e=>setMfa(e.target.value.replace(/\D/g,""))} autoComplete="one-time-code"/></>}
   <p><button type="submit" disabled={busy}>{busy?"Please wait...":register?"Create account":"Sign in"}</button></p>
  </form>
  {error&&<div role="alert"><p className="err">{error}</p>{correctPath&&<p><a href={correctPath}>Go to the correct sign-in page</a></p>}</div>}
  {portal==="CUSTOMER"&&<button type="button" className="ghost" onClick={()=>{setRegister(v=>!v);setError("");setCorrectPath(null)}}>{register?"Back to sign in":"Create customer account"}</button>}
  {portal==="DRIVER"&&<p><a href="/become-driver">Apply to become a driver</a></p>}
  <p className="muted">Demo environment. Authorized accounts only.</p>
 </div></main>;
}
