import {session} from "../../../lib/auth";
import {redirect} from "next/navigation";
import AdminAccountManager from "./ui";
export default async function Page(){const u=await session();if(!u)redirect("/admin/login");if(u.role!=="ADMIN"||!process.env.SUPER_ADMIN_EMAIL||u.email.toLowerCase()!==process.env.SUPER_ADMIN_EMAIL.toLowerCase().trim())return <main className="wrap"><h1>Super Admin only</h1></main>;return <main className="wrap"><span className="pill">PICKPACK · SUPER ADMIN</span><h1>Admin account management</h1><p>To add an admin, first have them register a customer account and securely configure an authenticator. Then promote their email here. Only the configured Super Admin can promote accounts.</p><AdminAccountManager/></main>}
