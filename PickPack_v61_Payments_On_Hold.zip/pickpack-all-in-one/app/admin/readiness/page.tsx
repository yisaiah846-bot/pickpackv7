import {session} from "../../../lib/auth";
import Link from "next/link";
export const dynamic="force-dynamic";
const items:[string,string,string][]=[
 ["Customer and driver messaging","Testing","Requires live account-to-account testing and dispatch-role authorization"],
 ["30-day message retention","Needs scheduler","Retention endpoint implemented; requires database update, cron secret, scheduled POST and legal-hold workflow"],
 ["Admin invitations and staff roles","Not ready","Secure email invitations and granular backend permissions not implemented"],
 ["Payments and driver payouts","Demo","Connect a payment processor, webhook verification, refunds and payouts"],
 ["Driver identity and document screening","Demo","Connect a screening provider and operational review"],
 ["Dispatch and real delivery operations","Demo","End-to-end field pilot, verified driver acceptance and operational staffing"],
 ["Live GPS and incident escalation","Testing","Validate permissions, consent, outage handling and emergency contacts"],
 ["Email delivery","Needs configuration","Configure SMTP and verify deliverability"],
 ["Security and production deployment","Not ready","MFA, role audits, backups, monitoring, rate limiting and security review"]
];
export default async function Readiness(){const u=await session();if(!u||u.role!=="ADMIN")return <main className="wrap"><h1>Access denied</h1></main>;
return <main className="wrap" style={{maxWidth:1000}}><span className="pill">PICKPACK · ADMIN</span><h1>Launch Readiness</h1><p className="muted">This is an honest status checklist, not a production certification. Demo payments and deliveries remain disabled for real-world use.</p><p><Link href="/admin">← Admin dashboard</Link></p><div className="card"><h2>Remaining work</h2>{items.map(([name,status,note])=><div key={name} style={{borderBottom:"1px solid #4c4025",padding:"14px 0"}}><strong>{name}</strong> · <span className="gold">{status}</span><p className="muted">{note}</p></div>)}</div></main>}
