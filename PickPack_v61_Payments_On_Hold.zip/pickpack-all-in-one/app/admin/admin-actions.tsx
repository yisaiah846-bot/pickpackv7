"use client";
import {useState} from "react";
type App={id:string,applicantId:string,vehicleDescription:string};
type Driver={id:string,name:string,email:string};
type Order={id:string,trackingNumber:string,status:string,driverId:string|null,pickupAddress:string,dropoffAddress:string,totalCents:number};
const closed=new Set(["DELIVERED","CANCELLED","RETURNED","REFUNDED"]);
export default function AdminActions({applications,drivers,orders}:{applications:App[],drivers:Driver[],orders:Order[]}){
 const [selected,setSelected]=useState<Record<string,string>>({});
 const [msg,setMsg]=useState("");const [busy,setBusy]=useState(false);
 const [filter,setFilter]=useState("active");
 async function action(data:object){setBusy(true);setMsg("");try{const r=await fetch("/api/demo/admin",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(data)});const j=await r.json();if(!r.ok)throw Error(j.error||"Request failed");setMsg(data&&"action" in data&&data.action==="retry_dispatch"?`Dispatch checked. ${j.assigned??0} waiting orders assigned.`:"Saved successfully.");setTimeout(()=>location.reload(),1100)}catch(e){setMsg(e instanceof Error?e.message:"Unexpected error")}finally{setBusy(false)}}
 const waiting=orders.filter(o=>o.status==="FINDING_DRIVER"&&!o.driverId);
 const active=orders.filter(o=>!closed.has(o.status));
 const finished=orders.filter(o=>closed.has(o.status));
 const visible=filter==="waiting"?waiting:filter==="history"?finished:active;
 return <>
 <section className="card"><h2>Driver applications</h2>{applications.length===0?<p className="muted">No pending applications</p>:applications.map(a=><article className="order" key={a.id}><p>Applicant ID: {a.applicantId}</p><p>Vehicle: {a.vehicleDescription}</p><button disabled={busy} onClick={()=>action({action:"approve",applicationId:a.id})}>Approve test driver</button></article>)}</section>
 <section className="card"><div className="dispatch-head"><div><div className="pill">AUTOMATIC · LOCAL DEMO</div><h2>Delivery Dispatch Center</h2><p className="muted">Demo bookings are assigned automatically to approved test drivers with capacity. You can retry matching or manually assign an exception below.</p></div><button disabled={busy||waiting.length===0} onClick={()=>action({action:"retry_dispatch"})}>↻ Retry automatic matching</button></div>
 <div className="dispatch-stats"><div><strong>{waiting.length}</strong><span>Waiting for driver</span></div><div><strong>{active.filter(o=>o.driverId).length}</strong><span>Assigned / in progress</span></div><div><strong>{finished.length}</strong><span>Past deliveries</span></div><div><strong>{drivers.length}</strong><span>Approved drivers</span></div></div>
 <p className="gold" role="status">{msg}</p>
 <div className="dispatch-filters"><button className={filter==="active"?"":"ghost"} onClick={()=>setFilter("active")}>Current jobs</button><button className={filter==="waiting"?"":"ghost"} onClick={()=>setFilter("waiting")}>Waiting ({waiting.length})</button><button className={filter==="history"?"":"ghost"} onClick={()=>setFilter("history")}>Past jobs</button></div>
 {visible.length===0?<p className="muted">No orders in this section.</p>:visible.map(o=><article className="order" key={o.id}><div className="pill">{o.status.replaceAll("_"," ")}</div><h3>{o.trackingNumber}</h3><p>{o.pickupAddress} → {o.dropoffAddress}</p><p className="muted">Example customer charge: ${(o.totalCents/100).toFixed(2)} — NOT COLLECTED</p><p>{o.driverId?"Driver assigned":"Awaiting an available driver"}</p>{o.status==="FINDING_DRIVER"&&!o.driverId&&<div className="dispatch-manual"><label htmlFor={`driver-${o.id}`}>Manual override (test only)</label><select id={`driver-${o.id}`} value={selected[o.id]||""} onChange={e=>setSelected(s=>({...s,[o.id]:e.target.value}))}><option value="">Choose approved test driver</option>{drivers.map(d=><option key={d.id} value={d.id}>{d.name} ({d.email})</option>)}</select><p><button disabled={busy||!selected[o.id]} onClick={()=>action({action:"assign",orderId:o.id,driverId:selected[o.id]})}>Assign demo order</button></p></div>}</article>)}
 <p className="muted">Demo only: this does not send driver offers, verify routes, charge cards, or dispatch real packages. Approved drivers are selected by creation order and limited to three active demo orders.</p></section>
 </>
}
