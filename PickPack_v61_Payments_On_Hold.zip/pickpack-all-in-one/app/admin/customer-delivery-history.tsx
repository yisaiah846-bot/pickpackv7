"use client";
import {useMemo,useState} from "react";
type Delivery={id:string;customerId:string;customerName:string;customerEmail:string;trackingNumber:string;status:string;pickupAddress:string;dropoffAddress:string;driverName:string|null;updatedAt:string;totalCents:number;proofReference:string|null;cancellationEvents:{id:string;note:string;createdAt:string}[]};
export default function CustomerDeliveryHistory({orders}:{orders:Delivery[]}){
 const [query,setQuery]=useState("");
 const [expanded,setExpanded]=useState<string[]>([]);
 const groups=useMemo(()=>{
  const map=new Map<string,{id:string;name:string;email:string;orders:Delivery[]}>();
  for(const order of orders){let g=map.get(order.customerId);if(!g){g={id:order.customerId,name:order.customerName,email:order.customerEmail,orders:[]};map.set(order.customerId,g);}g.orders.push(order);}
  return [...map.values()].sort((a,b)=>a.name.localeCompare(b.name));
 },[orders]);
 const normalized=query.trim().toLowerCase();
 const filtered=groups.filter(g=>!normalized||[g.name,g.email,...g.orders.map(o=>o.trackingNumber)].some(v=>v.toLowerCase().includes(normalized)));
 return <div><h2>Delivery History by Customer</h2><p className="muted">Select a customer to view their completed and canceled deliveries. Customer records are grouped by account ID.</p>
 <label htmlFor="history-search">Search customer or tracking number</label>
 <input id="history-search" aria-label="Search customer or tracking number" style={{display:"block",width:"100%",maxWidth:480,margin:"10px 0 18px",padding:12,borderRadius:8,background:"#15161a",color:"white",border:"1px solid #665526"}} value={query} onChange={e=>setQuery(e.target.value)} placeholder="Name, email, tracking number"/>
 {filtered.map(g=>{const open=expanded.includes(g.id)||Boolean(normalized&&g.orders.some(o=>o.trackingNumber.toLowerCase().includes(normalized)));return <div key={g.id} style={{border:"1px solid #514629",borderRadius:12,padding:16,marginBottom:12}}>
 <button type="button" aria-expanded={open} onClick={()=>setExpanded(a=>a.includes(g.id)?a.filter(x=>x!==g.id):[...a,g.id])} style={{background:"transparent",border:0,color:"#e4b62f",cursor:"pointer",fontSize:17,fontWeight:700,textAlign:"left",width:"100%"}}>{g.name} · {g.orders.length} {g.orders.length===1?"delivery":"deliveries"} {open?"▴":"▾"}</button><p className="muted">{g.email}</p>
 {open&&g.orders.filter(o=>!normalized||!g.orders.some(x=>x.trackingNumber.toLowerCase().includes(normalized))||o.trackingNumber.toLowerCase().includes(normalized)).map(o=><div key={o.id} className="order"><b className="gold">{o.trackingNumber}</b> · {o.status}<p>{o.pickupAddress} → {o.dropoffAddress}</p><p className="muted">{new Date(o.updatedAt).toLocaleString()} · Driver: {o.driverName||"Not assigned"} · Amount: ${(o.totalCents/100).toFixed(2)}</p>{o.cancellationEvents.map(e=><p className="muted" key={e.id}>Cancellation record · {new Date(e.createdAt).toLocaleString()}: {e.note}</p>)}{o.proofReference&&<p className="muted">Proof of delivery on file (view through authorized proof-of-delivery workflow).</p>}</div>)}
 </div>})}
 {filtered.length===0&&<p className="muted">No matching customers or deliveries.</p>}
 </div>;
}
