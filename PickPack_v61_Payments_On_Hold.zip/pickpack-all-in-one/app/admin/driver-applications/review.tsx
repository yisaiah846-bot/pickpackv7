"use client";
import {useState} from "react";
type A={id:string;applicant:string;email:string;vehicleDescription:string;status:string;createdAt:Date;denialReason:string};
export default function ApplicationActions({applications}:{applications:A[]}){
 const [busy,setBusy]=useState(false);const [msg,setMsg]=useState("");const [reasons,setReasons]=useState<Record<string,string>>({});
 async function review(id:string,action:"approve"|"deny"){
  const reason=(reasons[id]||"").trim();if(action==="deny"&&reason.length<3){setMsg("Enter a denial reason (at least 3 characters).");return}
  setBusy(true);setMsg("");try{const r=await fetch("/api/demo/admin",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({action,applicationId:id,...(action==="deny"?{reason}:{})})});const j=await r.json();if(!r.ok)throw Error(j.error||"Review failed");window.location.reload()}catch(e){setMsg(e instanceof Error?e.message:"Failed")}finally{setBusy(false)}
 }
 const pending=applications.filter(a=>a.status==="PENDING"),denied=applications.filter(a=>a.status==="DENIED");
 return <><section className="card"><h2>Pending Applications ({pending.length})</h2><p role="status" className="gold">{msg}</p>{pending.length===0?<p>No applications awaiting review.</p>:pending.map(a=><article className="order" key={a.id}><span className="pill">PENDING</span><h3>{a.applicant}</h3><p>{a.email}</p><p>{a.vehicleDescription}</p><p className="muted">Submitted {new Date(a.createdAt).toLocaleString()}</p><button disabled={busy} onClick={()=>review(a.id,"approve")}>Approve demo driver</button><label style={{display:"block",marginTop:12}}>Denial reason <textarea style={{display:"block",width:"100%"}} maxLength={500} value={reasons[a.id]||""} onChange={e=>setReasons({...reasons,[a.id]:e.target.value})} placeholder="Explain why the application was denied" /></label><button disabled={busy||!(reasons[a.id]||"").trim()} onClick={()=>review(a.id,"deny")}>Deny application</button></article>)}</section><section className="card" id="denied-applications"><h2>Denied Applications ({denied.length})</h2>{denied.length===0?<p>No denied applications.</p>:denied.map(a=><article className="order" key={a.id}><span className="pill">DENIED</span><h3>{a.applicant}</h3><p>{a.email}</p><p>{a.vehicleDescription}</p><p className="muted">Reason: {a.denialReason}</p></article>)}</section></>
}
