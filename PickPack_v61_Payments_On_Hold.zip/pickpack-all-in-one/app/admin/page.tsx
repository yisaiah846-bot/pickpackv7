import VerificationReview from "./verification-review";
import {session} from "../../lib/auth";
import {db} from "../../lib/db";
import Link from "next/link";
import AdminActions from "./admin-actions";
import SupportAdmin from "./support-admin";
import DriverDiscipline from "./driver-discipline";
import CustomerDeliveryHistory from "./customer-delivery-history";
export const dynamic="force-dynamic";
const closed=new Set(["DELIVERED","CANCELLED","RETURNED","REFUNDED"]);
export default async function Admin(){
 const user=await session();
 if(!user)return <main className="wrap"><h1>Admin access</h1><Link href="/admin/login">Sign in</Link></main>;
 if(user.role!=="ADMIN")return <main className="wrap"><h1>Access denied</h1><p>Admin access required.</p></main>;
 const [tickets,orders,apps,drivers,customers]=await Promise.all([
 db.supportTicket.findMany({orderBy:{createdAt:"desc"},take:100}),
 db.order.findMany({orderBy:{createdAt:"desc"},take:100}),
 db.driverApplication.findMany({where:{status:"PENDING"}}),
 db.user.findMany({where:{role:"DRIVER"},select:{id:true,name:true,email:true}}),
 db.user.findMany({where:{role:"CUSTOMER"},select:{id:true,name:true,email:true,createdAt:true},orderBy:{createdAt:"desc"},take:100})
 ]);
 const deniedCount=await db.driverApplication.count({where:{status:"DENIED"}});
 const documents=await db.driverVerificationDocument.findMany({where:{status:"PENDING"},include:{driver:{select:{name:true}}},orderBy:{createdAt:"desc"},take:100});
 const history=await db.driverDiscipline.findMany({where:{driverId:{in:drivers.map(d=>d.id)}},orderBy:{createdAt:"desc"},take:500});
 const monthStart=new Date();monthStart.setDate(1);monthStart.setHours(0,0,0,0);
 const monthOrders=await db.order.findMany({where:{createdAt:{gte:monthStart}}});
 const paid=monthOrders.filter(o=>o.paymentStatus==="PAID"&&o.status!=="REFUNDED");
 const gross=paid.reduce((s,o)=>s+o.totalCents,0),driversOwed=paid.reduce((s,o)=>s+o.driverEarningsCents,0);
 const active=orders.filter(o=>!closed.has(o.status)),past=orders.filter(o=>closed.has(o.status)&&o.status!=="CANCELLED");
 const customerPast=await db.order.findMany({where:{status:{in:["DELIVERED","RETURNED","REFUNDED","CANCELLED"]}},include:{customer:{select:{id:true,name:true,email:true}},driver:{select:{name:true}},events:{where:{note:{contains:"cancel",mode:"insensitive"}},orderBy:{createdAt:"desc"}}},orderBy:{updatedAt:"desc"}});
 const sevenHoursAgo=new Date(Date.now()-7*60*60*1000);
 const canceled=await db.order.findMany({where:{status:"CANCELLED",updatedAt:{gte:sevenHoursAgo}},orderBy:{updatedAt:"desc"},take:200,include:{events:{orderBy:{createdAt:"desc"},take:20}}});
 const reassignmentEvents=await db.orderEvent.findMany({where:{note:{contains:"cancel",mode:"insensitive"},createdAt:{gte:sevenHoursAgo}},orderBy:{createdAt:"desc"},take:200,include:{order:{select:{trackingNumber:true,pickupAddress:true,dropoffAddress:true,status:true}}}});
 const money=(c:number)=>"$"+(c/100).toFixed(2);
 return <main className="wrap admin-v9">
 <VerificationReview docs={documents.map(d=>({id:d.id,kind:d.kind,status:d.status,driverName:d.driver.name,expiresAt:d.expiresAt?.toISOString().slice(0,10)||null}))}/>
  <span className="pill">PICKPACK · ADMIN</span>{process.env.SUPER_ADMIN_EMAIL&&user.email.toLowerCase()===process.env.SUPER_ADMIN_EMAIL.toLowerCase().trim()&&<p><Link href="/admin/admin-accounts">Manage admin accounts</Link></p>}<h1>Operations dashboard</h1><p><Link href="/admin/readiness">View launch readiness and unfinished integrations →</Link></p>
  <p className="muted">Manage drivers, customers, support and dispatch from one place. Click a card to jump to its section.</p>
  <div className="admin-kpis">
   <a href="#current-jobs" className="admin-kpi"><span>Current deliveries</span><strong>{active.length}</strong><small>View active jobs ↗</small></a>
   <a href="#canceled-jobs" className="admin-kpi"><span>Canceled deliveries</span><strong>{canceled.length}</strong><small>View cancellations ↗</small></a>
   <a href="#past-jobs" className="admin-kpi"><span>Past deliveries</span><strong>{past.length}</strong><small>View job history ↗</small></a>
   <a href="/admin/driver-applications" className="admin-kpi"><span>Pending drivers</span><strong>{apps.length}</strong><small>Open applications ↗</small></a>
   <a href="/admin/driver-applications#denied-applications" className="admin-kpi"><span>Denied applications</span><strong>{deniedCount}</strong><small>View denied applicants ↗</small></a>
   <a href="#drivers" className="admin-kpi"><span>Approved drivers</span><strong>{drivers.length}</strong><small>Names & discipline ↗</small></a>
   <a href="#customers" className="admin-kpi"><span>Customers</span><strong>{customers.length}</strong><small>View accounts ↗</small></a>
   <a href="#support" className="admin-kpi"><span>Bot escalations</span><strong>{tickets.filter(t=>t.status!=="RESOLVED").length}</strong><small>Respond to bot handoffs ↗</small></a>
  </div>
  <section className="card" id="earnings"><div className="split"><h2>Company earnings this month</h2><span className="pill">Recorded payments only</span></div><div className="admin-finances"><div><span>Payments collected</span><strong>{money(gross)}</strong></div><div><span>Driver earnings</span><strong>{money(driversOwed)}</strong></div><div><span>Company share before expenses</span><strong>{money(gross-driversOwed)}</strong></div></div><p className="muted">Demo orders are unpaid and excluded. These are database totals, not verified accounting or net profit.</p></section>
  <section className="card" id="customers"><h2>Customer directory</h2><p className="muted">Names and account information. Customer warnings, suspension and ban controls require a separate secured implementation and are not enabled here.</p><div className="admin-table"><table><thead><tr><th>Customer</th><th>Email</th><th>Joined</th><th>Orders</th></tr></thead><tbody>{customers.map(c=><tr key={c.id}><td>{c.name}</td><td>{c.email}</td><td>{c.createdAt.toLocaleDateString()}</td><td>{orders.filter(o=>o.customerId===c.id).length}</td></tr>)}</tbody></table></div>{customers.length===0&&<p>No customers found.</p>}</section>
  <section id="drivers"><DriverDiscipline drivers={drivers.map(d=>({...d,history:history.filter(h=>h.driverId===d.id).map(h=>({id:h.id,action:h.action,reason:h.reason,createdAt:h.createdAt.toISOString(),suspensionEndsAt:h.suspensionEndsAt?.toISOString()||null}))}))}/></section>
  <section id="support"><SupportAdmin tickets={tickets.map(t=>({id:t.id,subject:t.subject,message:t.message,status:t.status,adminReply:t.adminReply}))}/></section>
  <section id="dispatch"><AdminActions applications={[]} drivers={drivers} orders={orders.map(o=>({id:o.id,trackingNumber:o.trackingNumber,status:o.status,driverId:o.driverId,pickupAddress:o.pickupAddress,dropoffAddress:o.dropoffAddress,totalCents:o.totalCents}))}/></section>
  <section className="card" id="current-jobs"><h2>Current deliveries</h2>{active.map(o=><div className="order" key={o.id}><b className="gold">{o.trackingNumber}</b> · {o.status}<p>{o.pickupAddress} → {o.dropoffAddress}</p></div>)}{active.length===0&&<p className="muted">No active deliveries.</p>}</section>
  <section className="card" id="canceled-jobs"><h2>Canceled Deliveries</h2><p className="muted">Recent cancellations appear here for 7 hours. Older records remain available in Delivery History by Customer below.</p>
   <h3>Canceled orders</h3>{canceled.map(o=><div className="order" key={o.id}><b className="gold">{o.trackingNumber}</b> · CANCELED<p>{o.pickupAddress} → {o.dropoffAddress}</p><p className="muted">Last updated: {o.updatedAt.toLocaleString()}</p>{o.events.filter(e=>e.note).map(e=><p key={e.id} className="muted">{e.createdAt.toLocaleString()}: {e.note}</p>)}</div>)}{canceled.length===0&&<p className="muted">No canceled orders.</p>}
   <h3>Driver cancellation / reassignment history</h3>{reassignmentEvents.map(e=><div className="order" key={e.id}><b className="gold">{e.order.trackingNumber}</b> · Current status: {e.order.status}<p>{e.order.pickupAddress} → {e.order.dropoffAddress}</p><p className="muted">{e.createdAt.toLocaleString()}: {e.note||"Driver cancellation"}</p></div>)}{reassignmentEvents.length===0&&<p className="muted">No recorded driver cancellations.</p>}
  </section>
  <section className="card" id="past-jobs"><CustomerDeliveryHistory orders={customerPast.map(o=>({id:o.id,customerId:o.customer.id,customerName:o.customer.name,customerEmail:o.customer.email,trackingNumber:o.trackingNumber,status:o.status,pickupAddress:o.pickupAddress,dropoffAddress:o.dropoffAddress,driverName:o.driver?.name||null,updatedAt:o.updatedAt.toISOString(),totalCents:o.totalCents,proofReference:o.proofReference,cancellationEvents:o.events.map(e=>({id:e.id,note:e.note||"Cancellation",createdAt:e.createdAt.toISOString()}))}))}/></section>
  <p className="muted">Demo environment. Real payment, GPS, driver screening and emergency services are not connected.</p>
 </main>
}
