import FloatingSupport from "./components/floating-support";
import "./globals.css";
import Link from "next/link";
import {session} from "../lib/auth";
import ProfileMenu from "./components/profile-menu";
export const metadata={title:"PickPack | Little Rock Delivery",description:"Package pickup and delivery in Little Rock"};
export default async function RootLayout({children}:{children:React.ReactNode}) {
 const user=await session();
 return <html lang="en"><body><nav className="nav"><Link className="brand" href="/">▣ PICKPACK</Link><Link href="/book">Book</Link><Link href="/track">Track</Link><Link href="/messages">Messages</Link><Link href="/dashboard">Customer</Link><Link href="/driver">Driver</Link><Link href="/admin">Admin</Link>{user?<ProfileMenu role={user.role}/>:<Link href="/login">Sign in</Link>}</nav>{children}<FloatingSupport/></body></html>;
}
