import {NextResponse} from "next/server";
export async function POST(){return NextResponse.json({error:"Email verification is unavailable. Use your PickPack account to view website messages."},{status:410});}
