import {NextResponse} from "next/server";
import {z} from "zod";
import bcrypt from "bcryptjs";
import {db} from "../../../../lib/db";
export async function POST(req:Request){
 try{
  const d=z.object({email:z.string().email(),code:z.string().regex(/^\d{6}$/)}).parse(await req.json());
  const user=await db.user.findUnique({where:{email:d.email.toLowerCase()}});
  if(!user||!user.emailVerificationRequired||user.emailVerified)return NextResponse.json({error:"Invalid verification request"},{status:400});
  if(!user.emailVerificationCodeHash||!user.emailVerificationExpiresAt||user.emailVerificationExpiresAt.getTime()<Date.now())return NextResponse.json({error:"Code expired. Request a new one."},{status:400});
  if(user.emailVerificationAttempts>=5)return NextResponse.json({error:"Too many attempts. Request a new code."},{status:429});
  if(!(await bcrypt.compare(d.code,user.emailVerificationCodeHash))){await db.user.update({where:{id:user.id},data:{emailVerificationAttempts:{increment:1}}});return NextResponse.json({error:"Invalid code"},{status:400})}
  await db.user.update({where:{id:user.id},data:{emailVerified:true,emailVerificationCodeHash:null,emailVerificationExpiresAt:null,emailVerificationSentAt:null,emailVerificationAttempts:0}});
  return NextResponse.json({ok:true});
 }catch{return NextResponse.json({error:"Invalid request"},{status:400})}
}
