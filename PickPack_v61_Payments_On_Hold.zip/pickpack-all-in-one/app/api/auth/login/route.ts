import {NextResponse} from "next/server";
import {z} from "zod";
import bcrypt from "bcryptjs";
import {authenticator} from "otplib";
import {db} from "../../../../lib/db";
import {issueSession} from "../../../../lib/auth";
const input=z.object({email:z.string().trim().email(),password:z.string().min(1),mfa:z.string().optional(),portal:z.enum(["ADMIN","DRIVER","CUSTOMER"])});
export async function POST(req:Request){
 let data:z.infer<typeof input>;
 try{data=input.parse(await req.json())}catch{return NextResponse.json({error:"Enter a valid email and password."},{status:400})}
 try{
  const user=await db.user.findUnique({
   where:{email:data.email.toLowerCase()},
   select:{id:true,email:true,passwordHash:true,role:true,mfaSecret:true,emailVerificationRequired:true,emailVerified:true}
  });
  if(!user||!(await bcrypt.compare(data.password,user.passwordHash)))return NextResponse.json({error:"Incorrect email or password."},{status:401});
  if(user.role!==data.portal){
   const correctPortal=user.role==="ADMIN"?"/admin/login":user.role==="DRIVER"?"/driver/login":"/login";
   return NextResponse.json({error:`This account belongs to the ${user.role.toLowerCase()} portal.`,correctPortal:user.role,correctPath:correctPortal},{status:403});
  }
  if(user.role==="ADMIN"){
   if(!user.mfaSecret)return NextResponse.json({error:"Admin authenticator is not configured. Contact the Super Admin or complete admin setup.",code:"ADMIN_MFA_SETUP_REQUIRED"},{status:403});
   if(!data.mfa||!/^\d{6}$/.test(data.mfa)||!authenticator.check(data.mfa,user.mfaSecret))return NextResponse.json({error:"Enter the current 6-digit authenticator code.",code:"INVALID_MFA"},{status:401});
  }
  if(user.role!=="CUSTOMER"&&user.emailVerificationRequired&&!user.emailVerified)return NextResponse.json({error:"Email verification is still required for this account. Contact support if you cannot receive the code.",requiresVerification:true},{status:403});
  await issueSession(user.id);
  return NextResponse.json({ok:true,role:user.role,redirectTo:user.role==="ADMIN"?"/admin":user.role==="DRIVER"?"/driver":"/dashboard"});
 }catch(e){
  console.error("[PickPack] login failure",e);
  const code=typeof e==="object"&&e!==null&&"code" in e?String((e as {code:unknown}).code):"";
  const msg=code==="P2022"?"Your database schema is out of date. Run npx prisma db push, then npx prisma generate and restart PickPack.":code==="P1001"?"Cannot reach the database. Check DATABASE_URL and that PostgreSQL is running.":code==="P2021"?"A required database table is missing. Run npx prisma db push.":"Sign-in service unavailable. Check your PickPack server terminal for details.";
  return NextResponse.json({error:msg,code:code||"LOGIN_SERVER_ERROR"},{status:500})
 }
}
