import {NextResponse} from "next/server";
import {z} from "zod";
import bcrypt from "bcryptjs";
import {db} from "../../../../lib/db";
import {issueSession} from "../../../../lib/auth";
const schema=z.object({name:z.string().trim().min(2).max(100),email:z.string().email().max(255),password:z.string().min(10).max(128)});
export async function POST(req:Request){
 try{
  const data=schema.parse(await req.json());const email=data.email.toLowerCase();
  if(await db.user.findUnique({where:{email}}))return NextResponse.json({error:"Email already registered"},{status:409});
  const user=await db.user.create({data:{name:data.name,email,passwordHash:await bcrypt.hash(data.password,12),role:"CUSTOMER",emailVerificationRequired:false,emailVerified:false}});
  await issueSession(user.id);
  return NextResponse.json({ok:true,requiresVerification:false,role:"CUSTOMER"});
 }catch{return NextResponse.json({error:"Invalid registration data"},{status:400})}
}
