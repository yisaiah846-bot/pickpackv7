import {NextResponse} from "next/server";import {cookies} from "next/headers";export async function POST(){(await cookies()).delete("pickpack_session");return NextResponse.json({ok:true})}
