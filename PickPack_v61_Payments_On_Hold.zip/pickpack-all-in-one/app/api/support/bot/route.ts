import {NextResponse} from "next/server";
import {z} from "zod";
import {session} from "../../../../lib/auth";
import {db} from "../../../../lib/db";

const input=z.object({message:z.string().trim().min(1).max(1500),escalate:z.boolean().optional()});
function answer(text:string){
 const q=text.toLowerCase();
 if(/human|person|agent|representative|admin|someone real|complaint|speak to/.test(q))return {reply:"I can connect you with the PickPack support team. Select 'Talk to a person' below to send your message to an admin.",needsHuman:true};
 if(/track|where.*(package|order|delivery)|status/.test(q))return {reply:"Open Track in the navigation to view your order status. This version does not have verified live GPS. For a missing or incorrect delivery update, select 'Talk to a person'.",needsHuman:false};
 if(/address|location|wrong street|apartment|gate/.test(q))return {reply:"Please confirm the full street address, city, apartment or suite, and any delivery instructions before booking. Automatic address suggestions are not connected yet. For a change to an existing order, select 'Talk to a person'.",needsHuman:false};
 if(/price|cost|fee|rate|charge|how much/.test(q))return {reply:"PickPack's listed rates are Scheduled $5.99 + $1.25/mile, Same-Day $7.99 + $1.50/mile, and Express $12.99 + $2.00/mile. Weight and overnight fees may apply. Demo mileage is not verified, so demo quotes are not final charges.",needsHuman:false};
 if(/cancel|refund|payment|charged|money back|billing/.test(q))return {reply:"Demo orders do not charge a card. If you need a cancellation, refund, or payment correction, select 'Talk to a person' so an admin can review it. I cannot issue refunds or change orders.",needsHuman:true};
 if(/driver|pickup|late|delay|missing|damaged|lost/.test(q))return {reply:"I can help you reach the PickPack team about your driver or delivery. Please choose 'Talk to a person' to send the issue to an admin. I cannot verify a driver's live location.",needsHuman:true};
 if(/hours|open|available|overnight/.test(q))return {reply:"PickPack plans 24/7 service when drivers are available. Overnight pickups may have an additional $5 fee. This demo does not confirm real-world driver availability.",needsHuman:false};
 return {reply:"I can help with tracking, booking addresses, pricing, delivery issues, and refunds. Try asking one of those questions, or choose 'Talk to a person' for admin help.",needsHuman:false};
}
export async function POST(req:Request){
 const u=await session();if(!u)return NextResponse.json({error:"Please sign in to use support"},{status:401});
 let data:z.infer<typeof input>;try{data=input.parse(await req.json())}catch{return NextResponse.json({error:"Enter a message (up to 1,500 characters)"},{status:400})}
 if(data.escalate){
  try{const ticket=await db.supportTicket.create({data:{customerId:u.id,subject:"Support bot escalation",message:data.message,status:"OPEN"}});return NextResponse.json({reply:"Your message was sent to PickPack support. An admin can reply in your support history below.",ticketId:ticket.id,escalated:true})}
  catch{return NextResponse.json({error:"Unable to send to support right now"},{status:500})}
 }
 return NextResponse.json(answer(data.message));
}
