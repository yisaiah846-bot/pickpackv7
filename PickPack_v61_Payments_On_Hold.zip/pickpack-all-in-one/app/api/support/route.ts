import {NextResponse} from "next/server";
import {z} from "zod";
import {session} from "../../../lib/auth";
import {db} from "../../../lib/db";
export async function GET(){const u=await session();if(!u)return NextResponse.json({error:"Sign in required"},{status:401});const tickets=await db.supportTicket.findMany({where:u.role==="ADMIN"?{}:{customerId:u.id},orderBy:{createdAt:"desc"},take:100});return NextResponse.json({tickets});}
export async function POST(req:Request){const u=await session();if(!u)return NextResponse.json({error:"Sign in required"},{status:401});try{const d=z.object({subject:z.string().trim().min(3).max(120),message:z.string().trim().min(10).max(4000),orderId:z.string().optional()}).parse(await req.json());if(d.orderId){const o=await db.order.findUnique({where:{id:d.orderId}});if(!o||o.customerId!==u.id)return NextResponse.json({error:"Order not found"},{status:404});}const ticket=await db.supportTicket.create({data:{customerId:u.id,...d}});return NextResponse.json({ticket},{status:201});}catch{return NextResponse.json({error:"Check your support request"},{status:400});}}
