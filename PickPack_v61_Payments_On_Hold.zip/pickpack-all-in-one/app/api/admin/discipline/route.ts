import {NextResponse} from "next/server";
import {z} from "zod";
import {db} from "../../../../lib/db";
import {session} from "../../../../lib/auth";
import {demoOnly} from "../../../../lib/demo";
const schema=z.object({driverId:z.string().min(1),action:z.enum(["WARNING","SUSPEND","DEACTIVATE","RESTORE"]),reason:z.string().trim().min(10).max(2000),evidenceNote:z.string().max(2000).optional(),days:z.number().int().min(1).max(365).optional()});
export async function POST(req:Request){
 const block=demoOnly();if(block)return block;
 const admin=await session();if(!admin||admin.role!=="ADMIN")return NextResponse.json({error:"Admin access required"},{status:403});
 const parsed=schema.safeParse(await req.json().catch(()=>null));if(!parsed.success)return NextResponse.json({error:"Enter a valid action and reason (10+ characters)"},{status:400});
 const {driverId,action,reason,evidenceNote,days}=parsed.data;
 const driver=await db.user.findUnique({where:{id:driverId},select:{id:true,role:true}});
 if(!driver||driver.role!=="DRIVER")return NextResponse.json({error:"Driver not found"},{status:404});
 if(action==="SUSPEND"&&!days)return NextResponse.json({error:"Select suspension duration"},{status:400});
 const suspensionEndsAt=action==="SUSPEND"?new Date(Date.now()+days!*86400000):null;
 await db.$transaction(async tx=>{
  await tx.driverDiscipline.create({data:{driverId,adminId:admin.id,action,reason,evidenceNote,suspensionEndsAt}});
  await tx.auditLog.create({data:{actorId:admin.id,action:"DRIVER_"+action,subjectId:driverId}});
  if(action==="SUSPEND"||action==="DEACTIVATE"){
   // Clear active demo assignments for re-dispatch; retain order history and record each change.
   const orders=await tx.order.findMany({where:{driverId,status:{notIn:["DELIVERED","CANCELLED","RETURNED","REFUNDED"]}},select:{id:true}});
   for(const order of orders){await tx.order.update({where:{id:order.id},data:{driverId:null,status:"FINDING_DRIVER"}});await tx.orderEvent.create({data:{orderId:order.id,actorId:admin.id,status:"FINDING_DRIVER",note:"Driver removed by admin discipline action; demo reassignment pending"}});}
  }
 });
 return NextResponse.json({ok:true});
}
