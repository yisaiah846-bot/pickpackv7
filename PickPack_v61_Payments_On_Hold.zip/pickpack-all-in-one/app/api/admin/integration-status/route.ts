import {NextResponse} from "next/server";
import {session} from "../../../../lib/auth";
export const dynamic="force-dynamic";
export async function GET(){
 const user=await session();
 if(!user||user.role!=="ADMIN")return NextResponse.json({error:"Unauthorized"},{status:403});
 const present=(...keys:string[])=>keys.every(key=>Boolean(process.env[key]?.trim()));
 const email=present("SMTP_HOST","SMTP_USER","SMTP_PASSWORD","SMTP_FROM");
 const payment=present("STRIPE_SECRET_KEY","STRIPE_WEBHOOK_SECRET");
 const identity=present("IDENTITY_PROVIDER_API_KEY","IDENTITY_PROVIDER_WEBHOOK_SECRET");
 const emergency=present("EMERGENCY_BACKUP_CONTACT","INCIDENT_NOTIFICATION_PROVIDER_KEY");
 return NextResponse.json({integrations:[
  {name:"Transactional email",configured:email,operational:false,detail:email?"SMTP credentials present; deliverability not tested":"Set SMTP_HOST, SMTP_USER, SMTP_PASSWORD, SMTP_FROM"},
  {name:"Card payments",configured:payment,operational:false,detail:payment?"Credentials present; payment and webhook workflows not integrated":"Choose payment provider and configure secure payment/webhook integration"},
  {name:"Driver identity screening",configured:identity,operational:false,detail:identity?"Credentials present; provider flow and consent still needed":"Choose identity screening provider and configure consent + webhook verification"},
  {name:"Emergency escalation",configured:emergency,operational:false,detail:emergency?"Contacts configured; escalation dispatch not integrated":"Add staffed backup contact, notification provider and incident response policy"}
 ],demoMode:true},{headers:{"Cache-Control":"no-store"}});
}
