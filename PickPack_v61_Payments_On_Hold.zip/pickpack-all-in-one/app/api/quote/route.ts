import {NextResponse} from "next/server";import {z} from "zod";import {quote} from "../../../lib/pricing";
const schema=z.object({service:z.enum(["SCHEDULED","SAME_DAY","EXPRESS"]),miles:z.number().positive().max(25),weight:z.number().positive().max(75),overnight:z.boolean(),tipCents:z.number().int().nonnegative().optional()});
export async function POST(req:Request){try{return NextResponse.json(quote(schema.parse(await req.json())))}catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Invalid quote"},{status:400})}}
