import {NextResponse} from "next/server";
import Stripe from "stripe";
import {db} from "../../../../lib/db";
export async function POST(req:Request){
 if(process.env.PICKPACK_PAYMENTS_RELEASED!=="true")return NextResponse.json({error:"Payments are on hold while PickPack is being prepared"},{status:503});
 const secret=process.env.STRIPE_WEBHOOK_SECRET,key=process.env.STRIPE_SECRET_KEY;
 if(!secret||!key)return NextResponse.json({error:"Webhook not configured"},{status:503});
 const sig=req.headers.get("stripe-signature");if(!sig)return NextResponse.json({error:"Missing signature"},{status:400});
 const stripe=new Stripe(key);
 let event:Stripe.Event;
 try{event=stripe.webhooks.constructEvent(await req.text(),sig,secret)}catch{return NextResponse.json({error:"Invalid signature"},{status:400})}
 if(event.type==="checkout.session.completed"){
  const checkout=event.data.object as Stripe.Checkout.Session;
  if(checkout.payment_status==="paid"&&checkout.client_reference_id){
   const order=await db.order.findUnique({where:{id:checkout.client_reference_id}});
   if(order&&!order.trackingNumber.startsWith("PP-DEMO-")&&!order.paymentStatus.startsWith("DEMO")&&checkout.amount_total===order.totalCents&&checkout.currency==="usd"){
    await db.order.updateMany({where:{id:order.id,paymentStatus:"UNPAID"},data:{paymentStatus:"PAID",paymentReference:checkout.id}});
   }
  }
 }
 return NextResponse.json({received:true});
}
