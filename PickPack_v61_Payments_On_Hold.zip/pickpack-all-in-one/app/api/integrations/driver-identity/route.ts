import {NextResponse} from "next/server";
import {session} from "../../../../lib/auth";
export async function POST(req:Request){
 const user=await session();
 if(!user||user.role!=="DRIVER")return NextResponse.json({error:"Driver sign-in required"},{status:403});
 if(process.env.IDENTITY_VERIFICATION_ENABLED!=="true")return NextResponse.json({error:"Identity verification is not enabled yet"},{status:503});
 const key=process.env.STRIPE_SECRET_KEY;
 if(!key)return NextResponse.json({error:"Stripe key is not configured"},{status:503});
 const url=new URL(req.url);
 const params=new URLSearchParams({type:"document",client_reference_id:user.id,return_url:url.origin+"/driver"});
 params.set("options[document][require_matching_selfie]","true");
 const response=await fetch("https://api.stripe.com/v1/identity/verification_sessions",{method:"POST",headers:{Authorization:"Bearer "+key,"Content-Type":"application/x-www-form-urlencoded","Idempotency-Key":"pickpack-identity-"+user.id+"-"+new Date().toISOString().slice(0,10)},body:params.toString(),cache:"no-store"});
 const result=await response.json();
 if(!response.ok)return NextResponse.json({error:"Identity provider unavailable"},{status:502});
 return NextResponse.json({url:result.url,status:result.status});
}
