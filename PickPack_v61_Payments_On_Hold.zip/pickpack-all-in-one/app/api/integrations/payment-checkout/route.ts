import {NextResponse} from "next/server";
import {session} from "../../../../lib/auth";
import {db} from "../../../../lib/db";
export async function POST(req:Request){
 if(process.env.PICKPACK_PAYMENTS_RELEASED!=="true")return NextResponse.json({error:"Payments are on hold while PickPack is being prepared"},{status:503});
 const user=await session();
 if(!user||user.role!=="CUSTOMER")return NextResponse.json({error:"Customer sign-in required"},{status:403});
 if(process.env.REAL_PAYMENTS_ENABLED!=="true")return NextResponse.json({error:"Real payments are disabled"},{status:503});
 const key=process.env.STRIPE_SECRET_KEY;
 if(!key)return NextResponse.json({error:"Stripe is not configured"},{status:503});
 const origin=req.headers.get("origin");if(origin&&origin!==new URL(req.url).origin)return NextResponse.json({error:"Invalid origin"},{status:403});
 const input=await req.json().catch(()=>({}));
 const order=typeof input.orderId==="string"?await db.order.findFirst({where:{id:input.orderId,customerId:user.id}}):null;
 if(!order)return NextResponse.json({error:"Order not found"},{status:404});
 if(order.trackingNumber.startsWith("PP-DEMO-")||order.paymentStatus.startsWith("DEMO"))return NextResponse.json({error:"Demo orders cannot be charged"},{status:409});
 if(order.paymentStatus!=="UNPAID"||order.totalCents<50)return NextResponse.json({error:"Order is not eligible for checkout"},{status:409});
 const originUrl=new URL(req.url).origin;
 const params=new URLSearchParams({mode:"payment",success_url:originUrl+"/track?payment=processing",cancel_url:originUrl+"/track?payment=cancelled",client_reference_id:order.id,"metadata[orderId]":order.id,"line_items[0][price_data][currency]":"usd","line_items[0][price_data][unit_amount]":String(order.totalCents),"line_items[0][price_data][product_data][name]":"PickPack delivery "+order.trackingNumber,"line_items[0][quantity]":"1"});
 const response=await fetch("https://api.stripe.com/v1/checkout/sessions",{method:"POST",headers:{Authorization:"Bearer "+key,"Content-Type":"application/x-www-form-urlencoded","Idempotency-Key":"pickpack-checkout-"+order.id},body:params,cache:"no-store"});
 if(!response.ok)return NextResponse.json({error:"Payment provider unavailable"},{status:502});
 const data=await response.json();return NextResponse.json({url:data.url});
}
