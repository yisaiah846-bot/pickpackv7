import {NextResponse} from "next/server";
import {session} from "../../../../lib/auth";
import {db} from "../../../../lib/db";
export async function POST(req:Request){
 const user=await session();
 if(!user||user.role!=="ADMIN")return NextResponse.json({error:"Admin only"},{status:403});
 if(process.env.EMERGENCY_SMS_ENABLED!=="true")return NextResponse.json({error:"Emergency SMS is disabled"},{status:503});
 const origin=req.headers.get("origin");if(origin&&origin!==new URL(req.url).origin)return NextResponse.json({error:"Invalid origin"},{status:403});
 const {orderId,description}=await req.json().catch(()=>({}));
 if(typeof orderId!=="string"||typeof description!=="string"||description.trim().length<10||description.length>500)return NextResponse.json({error:"Valid delivery and incident description required"},{status:400});
 const order=await db.order.findUnique({where:{id:orderId},select:{trackingNumber:true}});
 if(!order)return NextResponse.json({error:"Delivery not found"},{status:404});
 const sid=process.env.TWILIO_ACCOUNT_SID,token=process.env.TWILIO_AUTH_TOKEN,from=process.env.TWILIO_FROM_NUMBER,to=process.env.EMERGENCY_BACKUP_CONTACT;
 if(!sid||!token||!from||!to)return NextResponse.json({error:"SMS provider or backup contact missing"},{status:503});
 const body=new URLSearchParams({From:from,To:to,Body:`PickPack incident ${order.trackingNumber}: ${description.trim()}. Contact dispatch immediately. This is not a substitute for 911.`});
 const response=await fetch(`https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(sid)}/Messages.json`,{method:"POST",headers:{Authorization:"Basic "+Buffer.from(sid+":"+token).toString("base64"),"Content-Type":"application/x-www-form-urlencoded"},body,cache:"no-store"});
 if(!response.ok){console.error("Twilio incident notification failed",response.status);return NextResponse.json({error:"Notification provider rejected request"},{status:502})}
 const data=await response.json();
 return NextResponse.json({queued:true,providerMessageId:data.sid,deliveryStatus:data.status});
}
