import {NextResponse} from "next/server";
import {session} from "../../../../lib/auth";
import {db} from "../../../../lib/db";
import {readFile,writeFile,mkdir} from "node:fs/promises";
import path from "node:path";import crypto from "node:crypto";
const root=path.resolve(process.cwd(),"private-uploads","avatars");
export async function GET(req:Request){const id=new URL(req.url).searchParams.get("id");if(!id)return new Response("Not found",{status:404});const u=await db.user.findUnique({where:{id},select:{avatarPath:true}});if(!u?.avatarPath)return new Response("Not found",{status:404});try{const bytes=await readFile(path.join(root,path.basename(u.avatarPath)));return new Response(bytes,{headers:{"content-type":"image/jpeg","cache-control":"private, max-age=60","x-content-type-options":"nosniff"}})}catch{return new Response("Not found",{status:404})}}
export async function POST(req:Request){const u=await session();if(!u)return NextResponse.json({error:"Unauthorized"},{status:401});const f=(await req.formData()).get("photo");if(!(f instanceof File)||f.size>2_000_000||f.size<100)return NextResponse.json({error:"Photo must be under 2 MB"},{status:400});const b=Buffer.from(await f.arrayBuffer());const jpeg=b[0]===255&&b[1]===216&&b[2]===255;if(!jpeg)return NextResponse.json({error:"Upload a JPEG image"},{status:400});await mkdir(root,{recursive:true});const key=crypto.randomUUID()+".jpg";await writeFile(path.join(root,key),b,{flag:"wx",mode:0o600});await db.user.update({where:{id:u.id},data:{avatarPath:key}});return NextResponse.json({ok:true})}
