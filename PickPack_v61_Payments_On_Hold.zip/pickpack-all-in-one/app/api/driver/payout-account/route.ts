import {NextResponse} from "next/server";
import Stripe from "stripe";
import {session} from "../../../../lib/auth";
import {db} from "../../../../lib/db";
const fail=(error:string,status=400)=>NextResponse.json({error},{status});
export async function GET(){
 if(process.env.PICKPACK_PAYMENTS_RELEASED!=="true")return NextResponse.json({connected:false,detailsSubmitted:false,payoutsEnabled:false,chargesEnabled:false,onHold:true});
 const user=await session();if(!user||user.role!=="DRIVER")return fail("Driver sign-in required",403);
 if(!user.stripeConnectAccountId)return NextResponse.json({connected:false,detailsSubmitted:false,payoutsEnabled:false,chargesEnabled:false});
 const key=process.env.STRIPE_SECRET_KEY;if(!key)return fail("Stripe not configured",503);
 try{const stripe=new Stripe(key);const account=await stripe.accounts.retrieve(user.stripeConnectAccountId);
 return NextResponse.json({connected:true,detailsSubmitted:account.details_submitted,payoutsEnabled:account.payouts_enabled,chargesEnabled:account.charges_enabled,requirementsDue:account.requirements?.currently_due?.length||0});}
 catch(e){console.error("Stripe Connect status",e);return fail("Unable to retrieve payout account",502)}
}
export async function POST(req:Request){
 if(process.env.PICKPACK_PAYMENTS_RELEASED!=="true")return NextResponse.json({error:"Payments are on hold while PickPack is being prepared"},{status:503});
 const user=await session();if(!user||user.role!=="DRIVER")return fail("Driver sign-in required",403);
 if(process.env.STRIPE_CONNECT_ENABLED!=="true")return fail("Driver payout onboarding is not enabled yet",503);
 const key=process.env.STRIPE_SECRET_KEY;if(!key)return fail("Stripe not configured",503);
 const origin=req.headers.get("origin");const base=new URL(req.url).origin;if(origin&&origin!==base)return fail("Invalid origin",403);
 try{const stripe=new Stripe(key);let accountId=user.stripeConnectAccountId;
 if(!accountId){const account=await stripe.accounts.create({type:"express",country:"US",email:user.email,metadata:{pickpackUserId:user.id}},{idempotencyKey:"pickpack-connect-"+user.id});
 accountId=account.id;await db.user.update({where:{id:user.id},data:{stripeConnectAccountId:accountId}})}
 const link=await stripe.accountLinks.create({account:accountId,refresh_url:base+"/driver/payouts",return_url:base+"/driver/payouts",type:"account_onboarding"});
 return NextResponse.json({url:link.url});
 }catch(e){console.error("Stripe Connect onboarding",e);return fail("Unable to start secure payout onboarding",502)}
}
