import {NextResponse} from "next/server";
import {z} from "zod";
import {db} from "../../../../lib/db";
import {session} from "../../../../lib/auth";
import {demoOnly} from "../../../../lib/demo";
export async function POST(req:Request){
 const blocked=demoOnly();if(blocked)return blocked;
 const user=await session();if(!user||user.role!=="CUSTOMER")return NextResponse.json({error:"Customer sign-in required"},{status:403});
 try{
  const {orderId}=z.object({orderId:z.string().min(1)}).parse(await req.json());
  const order=await db.order.findFirst({where:{id:orderId,customerId:user.id}});
  if(!order)return NextResponse.json({error:"Order not found"},{status:404});
  if(!["BOOKED","FINDING_DRIVER","DRIVER_ASSIGNED","HEADING_TO_PICKUP","AT_PICKUP"].includes(order.status))return NextResponse.json({error:"This delivery can no longer be cancelled automatically"},{status:409});
  const changed=await db.order.updateMany({where:{id:order.id,customerId:user.id,status:order.status},data:{status:"CANCELLED"}});
  if(changed.count!==1)return NextResponse.json({error:"Delivery changed; refresh and try again"},{status:409});
  await db.orderEvent.create({data:{orderId:order.id,status:"CANCELLED",actorId:user.id,note:"Customer cancelled simulated delivery; no payment charged"}});
  return NextResponse.json({ok:true});
 }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Invalid request"},{status:400})}
}
