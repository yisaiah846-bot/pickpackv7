import {NextResponse} from "next/server";
import {z} from "zod";
import {db} from "../../../../lib/db";
import {session} from "../../../../lib/auth";
import {demoOnly} from "../../../../lib/demo";
const eligible=["DRIVER_ASSIGNED","HEADING_TO_PICKUP","AT_PICKUP"] as const;
export async function POST(req:Request){
 const blocked=demoOnly();if(blocked)return blocked;
 const user=await session();if(!user||user.role!=="DRIVER")return NextResponse.json({error:"Approved driver required"},{status:403});
 try{
 const {orderId,reason}=z.object({orderId:z.string().min(1),reason:z.string().trim().min(3).max(300)}).parse(await req.json());
 const result=await db.$transaction(async tx=>{
 const order=await tx.order.findFirst({where:{id:orderId,driverId:user.id}});
 if(!order)return {error:"Assigned delivery not found",status:404};
 if(!eligible.includes(order.status as typeof eligible[number]))return {error:"Cancellation is not allowed after package pickup",status:409};
 const changed=await tx.order.updateMany({where:{id:orderId,driverId:user.id,status:order.status},data:{driverId:null,status:"FINDING_DRIVER"}});
 if(changed.count!==1)return {error:"Delivery changed; refresh",status:409};
 await tx.orderEvent.create({data:{orderId,actorId:user.id,status:"FINDING_DRIVER",note:"Driver cancelled before pickup; available for another driver. Reason: "+reason}});
 await tx.auditLog.create({data:{actorId:user.id,action:"DRIVER_CANCEL_BEFORE_PICKUP",subjectId:orderId}});
 return {ok:true,status:"FINDING_DRIVER"};
 });
 return NextResponse.json(result,{status:"error" in result?result.status:200});
 }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Invalid request"},{status:400})}
}
