import {NextResponse} from "next/server";
import {db} from "../../../../lib/db";
import {session} from "../../../../lib/auth";
import {demoOnly} from "../../../../lib/demo";

export async function POST(req:Request){
 const blocked=demoOnly();if(blocked)return blocked;
 const user=await session();if(!user||user.role!=="DRIVER")return NextResponse.json({error:"Approved driver required"},{status:403});
 try{
  const form=await req.formData();const orderId=form.get("orderId");const photo=form.get("photo");
  if(typeof orderId!=="string"||!(photo instanceof File))return NextResponse.json({error:"Take a delivery photo before completing"},{status:400});
  if(photo.size<100||photo.size>1500000)return NextResponse.json({error:"Photo must be under 1.5 MB"},{status:400});
  if(!["image/jpeg","image/png","image/webp"].includes(photo.type))return NextResponse.json({error:"Upload a JPG, PNG or WebP photo"},{status:400});
  const bytes=Buffer.from(await photo.arrayBuffer());
  const jpg=bytes[0]===255&&bytes[1]===216&&bytes[2]===255;
  const png=bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
  const webp=bytes.toString("ascii",0,4)==="RIFF"&&bytes.toString("ascii",8,12)==="WEBP";
  if(!((photo.type==="image/jpeg"&&jpg)||(photo.type==="image/png"&&png)||(photo.type==="image/webp"&&webp)))return NextResponse.json({error:"Invalid image file"},{status:400});
  const proof=`data:${photo.type};base64,${bytes.toString("base64")}`;
  const result=await db.$transaction(async tx=>{
   const changed=await tx.order.updateMany({where:{id:orderId,driverId:user.id,status:"ARRIVING"},data:{status:"DELIVERED",proofReference:proof}});
   if(changed.count!==1)return false;
   await tx.orderEvent.create({data:{orderId,actorId:user.id,status:"DELIVERED",note:"Demo delivery completed with required photo proof"}});
   await tx.auditLog.create({data:{actorId:user.id,action:"DELIVERY_PHOTO_PROOF",subjectId:orderId}});
   return true;
  });
  return result?NextResponse.json({ok:true,status:"DELIVERED"}):NextResponse.json({error:"Order is not awaiting drop-off or is no longer assigned to you"},{status:409});
 }catch(e){console.error("Delivery photo proof failed",e);return NextResponse.json({error:"Unable to save delivery photo"},{status:500});}
}

export async function GET(req:Request){
 const user=await session();if(!user)return NextResponse.json({error:"Sign in required"},{status:401});
 const id=new URL(req.url).searchParams.get("orderId");if(!id)return NextResponse.json({error:"Missing order"},{status:400});
 const order=await db.order.findUnique({where:{id},select:{customerId:true,driverId:true,status:true,proofReference:true}});
 if(!order||(user.role!=="ADMIN"&&user.id!==order.customerId&&user.id!==order.driverId))return NextResponse.json({error:"Not authorized"},{status:403});
 if(order.status!=="DELIVERED"||!order.proofReference?.startsWith("data:image/"))return new Response("<!doctype html><html lang=\"en\"><meta charset=\"utf-8\"><title>Delivery photo unavailable</title><body style=\"font-family:system-ui;background:#121212;color:#eee;padding:3rem\"><h1>Delivery photo unavailable</h1><p>No delivery photo uploaded for this delivery.</p><p><a style=\"color:#e3b930\" href=\"/driver\">Return to Driver Dashboard</a></p></body></html>",{status:404,headers:{"content-type":"text/html; charset=utf-8","cache-control":"private, no-store"}});
 const match=/^data:(image\/(?:jpeg|png|webp));base64,(.+)$/.exec(order.proofReference);
 if(!match)return NextResponse.json({error:"Photo unavailable"},{status:404});
 return new Response(Buffer.from(match[2],"base64"),{headers:{"content-type":match[1],"cache-control":"private, no-store","x-content-type-options":"nosniff"}});
}
