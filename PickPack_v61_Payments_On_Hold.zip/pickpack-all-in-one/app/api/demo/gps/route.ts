import {NextResponse} from "next/server";
import {session} from "../../../../lib/auth";
import {db} from "../../../../lib/db";
import {demoOnly} from "../../../../lib/demo";
const active=["DRIVER_ASSIGNED","HEADING_TO_PICKUP","AT_PICKUP","PICKED_UP","IN_TRANSIT","ARRIVING"];
export async function POST(req:Request){
 const blocked=demoOnly();if(blocked)return blocked;
 const user=await session();if(!user||user.role!=="DRIVER")return NextResponse.json({error:"Driver only"},{status:403});
 try{const d=await req.json();if(typeof d.orderId!=="string")throw Error("Missing order");
 const order=await db.order.findFirst({where:{id:d.orderId,driverId:user.id}});if(!order)return NextResponse.json({error:"Not assigned"},{status:403});
 if(d.stop===true||!active.includes(order.status)){await db.driverGps.deleteMany({where:{orderId:order.id,driverId:user.id}});return NextResponse.json({ok:true,stopped:true})}
 if(typeof d.lat!=="number"||typeof d.lon!=="number"||!Number.isFinite(d.lat)||!Number.isFinite(d.lon)||Math.abs(d.lat)>90||Math.abs(d.lon)>180)throw Error("Invalid GPS");
 await db.driverGps.upsert({where:{orderId:order.id},create:{orderId:order.id,driverId:user.id,lat:d.lat,lon:d.lon},update:{lat:d.lat,lon:d.lon,driverId:user.id}});return NextResponse.json({ok:true});
 }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Invalid request"},{status:400})}
}
