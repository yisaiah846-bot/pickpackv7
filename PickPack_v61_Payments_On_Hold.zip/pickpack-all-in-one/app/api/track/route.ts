import {NextResponse} from "next/server";
import {session} from "../../../lib/auth";
import {db} from "../../../lib/db";
import {addresses} from "../../../lib/address-data";
export async function GET(req:Request){
 try {
 const user=await session();if(!user)return NextResponse.json({error:"Sign in required"},{status:401});
 const tracking=new URL(req.url).searchParams.get("tracking")?.trim();if(!tracking||tracking.length>100)return NextResponse.json({error:"Valid tracking number required"},{status:400});
 const order=await db.order.findUnique({where:{trackingNumber:tracking},include:{events:{orderBy:{createdAt:"asc"},select:{status:true,createdAt:true,note:true}}}});
 if(!order||!(user.role==="ADMIN"||order.customerId===user.id||order.driverId===user.id))return NextResponse.json({error:"Tracking number not found in your account"},{status:404});
 // Existing demo bookings may predate coordinate storage. Match them against the imported local address catalog.
 const normalize=(s:string)=>s.toLowerCase().replace(/[^a-z0-9]/g,'');
 const catalog=addresses();
 const locate=(label:string,lat:number|null,lng:number|null)=>{
  if(lat!==null&&lng!==null&&Number.isFinite(lat)&&Number.isFinite(lng))return {lat,lon:lng,label};
  const match=catalog.find(a=>normalize(a.label)===normalize(label));
  return match?{lat:match.lat,lon:match.lon,label}:null;
 };
 const pickup=locate(order.pickupAddress,order.pickupLat,order.pickupLng);
 const dropoff=locate(order.dropoffAddress,order.dropoffLat,order.dropoffLng);
 let geometry:{coordinates:number[][]}|null=null;
 let durationMinutes:number|null=null;
 if(pickup&&dropoff){try{
  const base=process.env.PICKPACK_ROUTING_URL||'https://router.project-osrm.org';
  const url=`${base}/route/v1/driving/${pickup.lon},${pickup.lat};${dropoff.lon},${dropoff.lat}?overview=full&geometries=geojson`;
  const response=await fetch(url,{cache:'no-store',signal:AbortSignal.timeout(6500)});
  if(response.ok){const data=await response.json();const route=data.routes?.[0];if(data.code==='Ok'&&route?.geometry?.coordinates?.length){geometry=route.geometry;durationMinutes=Math.round(route.duration/60)}}
 }catch{/* The timeline still works if the routing provider is offline. */}}
 // A deployment with an older schema should still show order and route details.
 let live: {lat:number;lon:number;updatedAt:Date}|null=null;
 if(order.driverId){
  try {live=await db.driverGps.findUnique({where:{orderId:order.id}})}
  catch(error){console.error("[PickPack GPS table unavailable; run prisma db push]",error)}
 }
 const driverPosition=live&&activeGps(order.status)&&Date.now()-live.updatedAt.getTime()<120000?{lat:live.lat,lon:live.lon}:null;
 return NextResponse.json({driverPosition,pickup,dropoff,geometry,durationMinutes,routeMiles:order.routeMiles,trackingNumber:order.trackingNumber,status:order.status,service:order.service,createdAt:order.createdAt,updatedAt:order.updatedAt,events:order.events.map(e=>({status:e.status,at:e.createdAt,note:e.note}))});
 } catch (error) {
  console.error("[PickPack tracking]", error);
  return NextResponse.json({error:"Tracking database or service unavailable. Check server logs and database connection."},{status:503});
 }
}

function activeGps(status:string){return !["DELIVERED","CANCELLED","CANCELED"].includes(status)}
