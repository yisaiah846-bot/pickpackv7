import {NextRequest,NextResponse} from "next/server";
import {session} from "../../../lib/auth";
import {db} from "../../../lib/db";

const historyCutoff=()=>new Date(Date.now()-30*24*60*60*1000);
const live = new Set(["DRIVER_ASSIGNED","HEADING_TO_PICKUP","AT_PICKUP","PICKED_UP","IN_TRANSIT","ARRIVING"]);
const error=(message:string,status=400)=>NextResponse.json({error:message},{status});
async function access(orderId:string){
 const user=await session();
 if(!user)return {error:error("Sign in required",401)};
 const order=await db.order.findUnique({where:{id:orderId},select:{id:true,trackingNumber:true,customerId:true,driverId:true,status:true,customer:{select:{name:true}},driver:{select:{name:true}}}});
 if(!order)return {error:error("Delivery not found",404)};
 if(user.role!=="ADMIN"&&user.id!==order.customerId&&user.id!==order.driverId)return {error:error("Not authorized",403)};
 return {user,order};
}
export async function GET(req:NextRequest){
 try {
 const orderId=req.nextUrl.searchParams.get("orderId")||"";
 if(!orderId)return error("Missing orderId");
 const a=await access(orderId);if(a.error)return a.error;
 const {user,order}=a as {user:NonNullable<Awaited<ReturnType<typeof session>>>,order:NonNullable<Awaited<ReturnType<typeof db.order.findUnique>>>};
 const messages=await db.deliveryMessage.findMany({where:{orderId,createdAt:{gte:historyCutoff()},...(user.role==="ADMIN"?{}:{driverId:order!.driverId||"__none__"})},orderBy:{createdAt:"asc"},take:300,include:{sender:{select:{name:true,role:true}}}});
 return NextResponse.json({messages,historyDays:30,active:live.has(order!.status)&&!!order!.driverId,order});
 } catch (cause) {
  console.error("[PickPack] Delivery message GET failed",cause);
  return NextResponse.json({error:"Unable to load messages. Check that the database schema is up to date (npx prisma db push) and restart the server."},{status:500});
 }
}
export async function POST(req:NextRequest){
 try {
 const origin=req.headers.get("origin");if(origin&&origin!==new URL(req.url).origin)return error("Invalid origin",403);
 let data:any;try{data=await req.json()}catch{return error("Invalid JSON")}
 const orderId=typeof data.orderId==="string"?data.orderId:"";
 const body=typeof data.body==="string"?data.body.trim():"";
 if(!orderId||!body||body.length>2000)return error("Message must be 1–2000 characters");
 const a=await access(orderId);if(a.error)return a.error;
 const {user,order}=a as any;
 if(user.role==="ADMIN")return error("Admin monitoring is read-only",403);
 if(!order.driverId||!live.has(order.status))return error("Messaging is only available during an assigned active delivery",403);
 // Conditional transaction prevents sending after completion/reassignment in the common race window.
 const result=await db.$transaction(async tx=>{
  const current=await tx.order.findUnique({where:{id:orderId},select:{driverId:true,status:true,customerId:true}});
  if(!current||!current.driverId||!live.has(current.status)||![current.customerId,current.driverId].includes(user.id))return null;
  return tx.deliveryMessage.create({data:{orderId,senderId:user.id,driverId:current.driverId,body}});
 });
 if(!result)return error("Delivery chat is no longer active",403);
 return NextResponse.json({message:result},{status:201});
 } catch(cause) {
  console.error("[PickPack] Delivery message POST failed",cause);
  return NextResponse.json({error:"Unable to send message. Please try again or contact support."},{status:500});
 }
}
