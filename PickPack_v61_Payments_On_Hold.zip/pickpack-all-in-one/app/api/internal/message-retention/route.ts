import {NextRequest,NextResponse} from "next/server";
import {db} from "../../../../lib/db";
export async function POST(req:NextRequest){
 const secret=process.env.RETENTION_CRON_SECRET;
 if(!secret||secret.length<32||req.headers.get("authorization")!==`Bearer ${secret}`)return NextResponse.json({error:"Unauthorized"},{status:401});
 try{
  const cutoff=new Date(Date.now()-30*24*60*60*1000);
  const holds=await db.messageLegalHold.findMany({where:{releasedAt:null},select:{orderId:true,driverId:true}});
  const heldOrders=holds.map(h=>h.orderId).filter((id):id is string=>!!id);
  const heldDrivers=holds.map(h=>h.driverId).filter((id):id is string=>!!id);
  const delivery=await db.deliveryMessage.deleteMany({where:{createdAt:{lt:cutoff},...(heldOrders.length?{orderId:{notIn:heldOrders}}:{})}});
  const staff=await db.staffDriverMessage.deleteMany({where:{createdAt:{lt:cutoff},...(heldDrivers.length?{driverId:{notIn:heldDrivers}}:{})}});
  console.info("[PickPack] message retention cleanup",{delivery:delivery.count,staff:staff.count});
  return NextResponse.json({ok:true,deliveryDeleted:delivery.count,staffDeleted:staff.count});
 }catch(e){console.error("[PickPack] retention cleanup failed",e);return NextResponse.json({error:"Retention cleanup failed; inspect server logs"},{status:500})}
}
