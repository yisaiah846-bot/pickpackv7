import {NextRequest,NextResponse} from "next/server";
import {session} from "../../../lib/auth";
import {db} from "../../../lib/db";
const err=(error:string,status=400)=>NextResponse.json({error},{status});
function dbError(e:unknown, action:string){
 console.error(`[PickPack] staff-driver-messages ${action}:`,e);
 const code=(e as {code?:string})?.code;
 if(code==="P2021"||code==="P2022") return err("Messaging database table is missing. Stop the server, run npx.cmd prisma db push and npx.cmd prisma generate, then restart.",503);
 if(e instanceof TypeError && String(e.message).includes("undefined"))return err("Prisma client needs regeneration. Stop the server, run npx.cmd prisma generate, then restart.",503);
 return err("Could not "+action.toLowerCase()+" staff messages. Check your Next.js terminal for the server error.",500);
}
export async function GET(req:NextRequest){
 try{
  const user=await session();if(!user)return err("Sign in required",401);
  if(user.role!=="ADMIN"&&user.role!=="DRIVER")return err("Forbidden",403);
  const driverId=user.role==="DRIVER"?user.id:req.nextUrl.searchParams.get("driverId");
  if(!driverId)return err("Driver required");
  const driver=await db.user.findFirst({where:{id:driverId,role:"DRIVER"},select:{id:true}});
  if(!driver)return err("Driver not found",404);
  const messages=await db.staffDriverMessage.findMany({where:{driverId,createdAt:{gte:new Date(Date.now()-30*86400000)}},orderBy:{createdAt:"asc"},take:500,include:{sender:{select:{name:true,role:true}}}});
  return NextResponse.json({messages});
 }catch(e){return dbError(e,"Load")}
}
export async function POST(req:NextRequest){
 try{
  const user=await session();if(!user)return err("Sign in required",401);
  if(user.role!=="ADMIN"&&user.role!=="DRIVER")return err("Forbidden",403);
  const origin=req.headers.get("origin");if(origin&&origin!==new URL(req.url).origin)return err("Invalid origin",403);
  let data:any;try{data=await req.json()}catch{return err("Invalid JSON")}
  const driverId=user.role==="DRIVER"?user.id:data.driverId;
  const body=typeof data.body==="string"?data.body.trim():"";
  if(typeof driverId!=="string"||!body||body.length>2000)return err("Message must be 1-2000 characters");
  const driver=await db.user.findFirst({where:{id:driverId,role:"DRIVER"},select:{id:true}});
  if(!driver)return err("Driver not found",404);
  const message=await db.staffDriverMessage.create({data:{driverId,senderId:user.id,body}});
  return NextResponse.json({message},{status:201});
 }catch(e){return dbError(e,"Send")}
}
