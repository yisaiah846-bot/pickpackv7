import {session} from "../../../lib/auth";import Link from "next/link";import PayoutControls from "./payout-controls";
export const dynamic="force-dynamic";
export default async function DriverPayouts(){const user=await session();if(!user||user.role!=="DRIVER")return <main className="wrap"><h1>Driver Payouts</h1><Link href="/driver/login">Driver sign in required</Link></main>;return <main className="wrap"><h1>Driver Payment Settings</h1><PayoutControls/></main>}
