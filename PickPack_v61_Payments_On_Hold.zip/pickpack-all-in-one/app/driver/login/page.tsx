import PortalLogin from "../../components/portal-login";
export default function Page(){return <PortalLogin portal="DRIVER"/>}
