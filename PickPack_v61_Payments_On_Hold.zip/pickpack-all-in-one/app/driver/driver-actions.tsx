"use client";
import {useEffect,useState} from "react";
import RouteMap from "../book/route-map";
type Order={id:string;trackingNumber:string;status:string;pickupAddress:string;dropoffAddress:string;driverEarningsCents:number;hasDeliveryPhoto:boolean};
type Tracking={pickup:{lat:number;lon:number;label:string}|null;dropoff:{lat:number;lon:number;label:string}|null;geometry:{coordinates:number[][]}|null;routeMiles:number;durationMinutes:number|null};
const mapsLink=(address:string)=>"https://www.google.com/maps/dir/?api=1&destination="+encodeURIComponent(address)+"&travelmode=driving";
const addressLink=(address:string)=><a href={mapsLink(address)} target="_blank" rel="noopener noreferrer" style={{color:"#e0b62e",textDecoration:"underline",textUnderlineOffset:3}} title="Open driving directions in Google Maps">{address} ↗</a>;
const steps:Record<string,string>={DRIVER_ASSIGNED:"Head to pickup",HEADING_TO_PICKUP:"Arrived at pickup",AT_PICKUP:"Simulate pickup",PICKED_UP:"Start simulated transit",IN_TRANSIT:"Approaching delivery",ARRIVING:"Take Delivery Photo"};
function Delivery({o,onAdvance}:{o:Order;onAdvance:(id:string)=>void}){
 const [cancelBusy,setCancelBusy]=useState(false);
 const [photo,setPhoto]=useState<File|null>(null);const [photoBusy,setPhotoBusy]=useState(false);const [photoError,setPhotoError]=useState("");
 async function completeWithPhoto(){if(!photo){setPhotoError("A delivery photo is required before completing.");return}setPhotoBusy(true);setPhotoError("");try{const body=new FormData();body.append("orderId",o.id);body.append("photo",photo);const r=await fetch("/api/demo/delivery-proof",{method:"POST",body});const j=await r.json();if(!r.ok)throw Error(j.error||"Could not save photo");window.location.reload()}catch(e){setPhotoError(e instanceof Error?e.message:"Upload failed")}finally{setPhotoBusy(false)}}
 async function cancelPickup(){const reason=window.prompt("Why are you cancelling this pickup? (Before pickup only)");if(reason===null)return;if(reason.trim().length<3){window.alert("Please enter a reason.");return;}if(!window.confirm("Cancel your assignment and make this pickup available to other drivers?"))return;setCancelBusy(true);try{const r=await fetch("/api/demo/driver-cancel",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({orderId:o.id,reason})});const data=await r.json();if(!r.ok)throw Error(data.error||"Cancellation failed");window.location.reload()}catch(e){window.alert(e instanceof Error?e.message:"Cancellation failed")}finally{setCancelBusy(false)}}
 const [gps,setGps]=useState<{lat:number;lon:number}|null>(null),[gpsError,setGpsError]=useState(""),[route,setRoute]=useState<Tracking|null>(null),[error,setError]=useState(""),[loading,setLoading]=useState(true);
 useEffect(()=>{let active=true;setLoading(true);fetch("/api/track?tracking="+encodeURIComponent(o.trackingNumber),{cache:"no-store"}).then(async r=>{const raw=await r.text();let data:Tracking & {error?:string};try{data=JSON.parse(raw)}catch{throw Error(r.ok?"Tracking service returned an empty response. Please retry.":`Tracking service error (${r.status}). Please retry.`)}if(!r.ok)throw Error(data.error||"Route unavailable");if(active){setRoute(data);setError("")}}).catch(e=>{if(active)setError(e.message)}).finally(()=>{if(active)setLoading(false)});return()=>{active=false}},[o.trackingNumber]);
 useEffect(()=>{if(["DELIVERED","CANCELLED","CANCELED","RETURNED","REFUNDED"].includes(o.status))return;if(!navigator.geolocation){setGpsError('GPS is unavailable on this device.');return}const watch=navigator.geolocation.watchPosition(pos=>{setGps({lat:pos.coords.latitude,lon:pos.coords.longitude});setGpsError('');void fetch("/api/demo/gps",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({orderId:o.id,lat:pos.coords.latitude,lon:pos.coords.longitude})})},err=>setGpsError(err.code===1?'Location permission denied. Enable location access in your browser.':'Unable to obtain GPS location.'),{enableHighAccuracy:true,maximumAge:5000,timeout:15000});return()=>navigator.geolocation.clearWatch(watch)},[o.id,o.status]);
  const finished = ["DELIVERED", "CANCELLED", "CANCELED", "RETURNED", "REFUNDED"].includes(o.status);
  return (
    <article className="order">
      <div className="pill">{o.status.replaceAll("_", " ")}</div>
      <h3>{o.trackingNumber}</h3>
      <p>Pickup: {addressLink(o.pickupAddress)}</p>
      <p>Drop-off: {addressLink(o.dropoffAddress)}</p>
      <p>Example earnings: ${(o.driverEarningsCents / 100).toFixed(2)}</p>
      {o.status === "ARRIVING" ? (
        <div>
          <label className="gold" htmlFor={`photo-${o.id}`}>Proof of delivery photo (required)</label>
          <p><input id={`photo-${o.id}`} type="file" accept="image/jpeg,image/png,image/webp" capture="environment" onChange={e => setPhoto(e.target.files?.[0] || null)} /></p>
          <button type="button" disabled={!photo || photoBusy} onClick={completeWithPhoto}>{photoBusy ? "Saving photo..." : "Complete Delivery With Photo"}</button>
          {photoError && <p role="alert">{photoError}</p>}
        </div>
      ) : steps[o.status] ? (
        <button onClick={() => onAdvance(o.id)}>{steps[o.status]}</button>
      ) : null}
      {o.status === "DELIVERED" && (
        o.hasDeliveryPhoto
         ? <p><a href={`/api/demo/delivery-proof?orderId=${encodeURIComponent(o.id)}`} target="_blank" rel="noopener noreferrer" className="gold">View delivery photo ↗</a></p>
         : <p className="muted">No delivery photo uploaded for this delivery.</p>
      )}
      {["DRIVER_ASSIGNED", "HEADING_TO_PICKUP", "AT_PICKUP"].includes(o.status) && (
        <button type="button" disabled={cancelBusy} onClick={cancelPickup} style={{ marginLeft: 8, background: "#6b2020" }}>Cancel Delivery Before Pickup</button>
      )}
      {!finished && (
        <div style={{ marginTop: 20 }}>
          <h3 className="gold">Delivery Navigation Map</h3>
          <div aria-live="polite" className="muted">{gps ? "GPS active during accepted delivery" : gpsError || "GPS activates during accepted delivery after location permission."}</div>
          {loading ? (
            <p className="muted">Loading delivery map...</p>
          ) : error ? (
            <>
              <p className="muted">Tracking temporarily unavailable: {error}</p>
              <p><a href={mapsLink(o.dropoffAddress)} target="_blank" rel="noopener noreferrer" className="gold">Open drop-off navigation in Google Maps ↗</a></p>
              {gps && <p className="muted">Your device GPS: {gps.lat.toFixed(5)}, {gps.lon.toFixed(5)}</p>}
            </>
          ) : route?.pickup && route?.dropoff ? (
            <>
              <RouteMap pickup={route.pickup} dropoff={route.dropoff} geometry={route.geometry || undefined} driverPosition={gps} />
              {route.geometry ? (
                <p className="gold">{Number(route.routeMiles || 0).toFixed(2)} miles · Approx. {route.durationMinutes ?? "—"} minutes</p>
              ) : (
                <p className="muted">Pickup and drop-off shown. Road route temporarily unavailable.</p>
              )}
            </>
          ) : (
            <p className="muted">This order's addresses could not be matched to map coordinates.</p>
          )}
          <p className="muted">GPS operates during accepted deliveries with device permission. You can revoke location access in browser settings. Browser must remain open. No turn-by-turn navigation.</p>
        </div>
      )}
    </article>
  );

}
export default function DriverActions({orders}:{orders:Order[]}){const [msg,setMsg]=useState("");async function advance(id:string){try{const r=await fetch("/api/demo/driver",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({orderId:id})});const j=await r.json();setMsg(r.ok?"Updated to "+j.status:j.error);if(r.ok)location.reload()}catch{setMsg("Unable to update demo delivery.")}}return <section className="card"><h2>Your assigned deliveries</h2><p className="gold">{msg}</p>{orders.length===0?<p>No assignments yet. Ask the demo admin to assign a test order.</p>:orders.map(o=><Delivery key={o.id} o={o} onAdvance={advance}/>)}</section>}

export function AvailablePickups(){const [orders,setOrders]=useState<Array<{id:string;trackingNumber:string;pickupAddress:string;dropoffAddress:string;driverEarningsCents:number}>>([]);const [message,setMessage]=useState("");useEffect(()=>{let live=true;const load=async()=>{try{const r=await fetch("/api/demo/available-pickups",{cache:"no-store"});if(!r.ok)return;const j=await r.json();if(live)setOrders(j.orders||[])}catch{}};void load();const timer=setInterval(load,12000);return()=>{live=false;clearInterval(timer)}},[]);async function accept(id:string){try{const r=await fetch("/api/demo/available-pickups",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({orderId:id})});const j=await r.json();if(!r.ok)throw Error(j.error||"Pickup unavailable");location.reload()}catch(e){setMessage(e instanceof Error?e.message:"Unable to accept pickup")}}return <section className="card"><h2>Available Pickups</h2><p className="muted">Unassigned demo orders, including pickups cancelled before collection. Refreshes every 12 seconds.</p>{message&&<p className="gold">{message}</p>}{orders.length===0?<p>No available pickups right now.</p>:orders.map(o=><article className="order" key={o.id}><h3>{o.trackingNumber}</h3><p>Pickup: {o.pickupAddress}</p><p>Drop-off: {o.dropoffAddress}</p><p>Simulated earnings: ${(o.driverEarningsCents/100).toFixed(2)}</p><button onClick={()=>accept(o.id)}>Accept Pickup</button></article>)}</section>}
