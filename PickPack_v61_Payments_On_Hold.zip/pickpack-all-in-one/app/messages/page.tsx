import Link from "next/link";
import {session} from "../../lib/auth";
import {db} from "../../lib/db";
import Chat from "./chat";
import AdminDirectory from "./admin-directory";
import StaffChat from "./staff-chat";
export const dynamic="force-dynamic";
export const metadata={title:"Messages | PickPack"};
export default async function MessagesPage(){
 const user=await session();
 if(!user)return <main className="wrap"><h1>Messages</h1><p>Sign in to view delivery messages.</p><Link href="/login">Customer sign in</Link> · <Link href="/driver/login">Driver sign in</Link> · <Link href="/admin/login">Admin sign in</Link></main>;
 const isAdmin=user.role==="ADMIN";
 const cutoff=new Date(Date.now()-30*24*60*60*1000);
 const recent={OR:[{status:{in:["DRIVER_ASSIGNED","HEADING_TO_PICKUP","AT_PICKUP","PICKED_UP","IN_TRANSIT","ARRIVING"]}},{updatedAt:{gte:cutoff}}]};
 if(isAdmin){
  const orders = await db.order.findMany({
    where: { AND: [{ driverId: { not: null } }, recent] },
    orderBy: { updatedAt: "desc" },
    take: 1000,
    select: {
      id: true,
      trackingNumber: true,
      status: true,
      updatedAt: true,
      customer: { select: { id: true, name: true, email: true } },
      driver: { select: { name: true, email: true } },
    },
  });
  const grouped=new Map<string,{id:string,name:string,email:string,orders:{id:string,trackingNumber:string,status:string,updatedAt:string,driver:{name:string,email:string}|null}[]}>();
  for(const o of orders){let c=grouped.get(o.customer.id);if(!c){c={id:o.customer.id,name:o.customer.name,email:o.customer.email,orders:[]};grouped.set(c.id,c)}c.orders.push({id:o.id,trackingNumber:o.trackingNumber,status:o.status,updatedAt:o.updatedAt.toISOString(),driver:o.driver})}
  const drivers=await db.user.findMany({where:{role:"DRIVER"},select:{id:true,name:true,email:true},orderBy:{name:"asc"},take:500});
  return <main className="wrap" style={{maxWidth:1000}}><span className="pill">PICKPACK COMMUNICATIONS</span><h1>Customer Message Monitoring</h1><p className="muted">Search customer information and review all their delivery conversations together. Read-only history for up to 30 days.</p><section className="card" style={{marginBottom:20}}><h2>Dispatch → Driver Messages</h2><p className="muted">Select a driver to send a private message, even if they have no active delivery.</p>{drivers.length===0?<p>No drivers found.</p>:drivers.map(d=><details key={d.id} style={{marginBottom:10,padding:12,border:"1px solid #6c5522",borderRadius:10}}><summary style={{cursor:"pointer",fontWeight:700}}>{d.name} · {d.email}</summary><StaffChat driverId={d.id} viewerId={user.id}/></details>)}</section><AdminDirectory customers={Array.from(grouped.values())} viewerId={user.id}/><p className="muted">Only authorized admins can view customer conversations. No messages can be sent from this monitoring screen.</p></main>;
 }
 const orders=await db.order.findMany({where:{AND:[user.role==="DRIVER"?{driverId:user.id}:{customerId:user.id,driverId:{not:null}},recent]},orderBy:{updatedAt:"desc"},take:60,select:{id:true,trackingNumber:true,status:true,customer:{select:{name:true}},driver:{select:{name:true}}}});
 return <main className="wrap" style={{maxWidth:960}}><span className="pill">PICKPACK COMMUNICATIONS</span><h1>Delivery Messages</h1>{user.role==="DRIVER"&&<section className="card" style={{marginBottom:20}}><h2>Admin / Dispatch Support</h2><p className="muted">Contact dispatch even when you do not have an active delivery.</p><StaffChat driverId={user.id} viewerId={user.id}/></section>}<p className="muted">Message your assigned delivery contact during pickup and delivery. Chats close after delivery or cancellation. Message history is available for up to 30 days.</p>{orders.length===0?<section className="card"><p className="muted">No assigned delivery conversations available.</p></section>:orders.map(o=><details className="card" key={o.id} style={{marginBottom:14}}><summary style={{cursor:"pointer",fontWeight:700}}>{o.trackingNumber} · {o.status.replaceAll("_"," ")} · {user.role==="DRIVER"?o.customer.name:o.driver?.name}</summary><Chat orderId={o.id} viewerId={user.id}/></details>)}<p className="muted">Only the assigned driver and booking customer can send messages. Reassigned drivers cannot access the new driver's chat. Message history is limited to the last 30 days.</p></main>;
}
