"use client";
import {useMemo,useState} from "react";
import Chat from "./chat";
type Delivery={id:string,trackingNumber:string,status:string,updatedAt:string,driver:{name:string,email:string}|null};
type Customer={id:string,name:string,email:string,orders:Delivery[]};
export default function AdminDirectory({customers,viewerId}:{customers:Customer[],viewerId:string}){
 const [query,setQuery]=useState("");
 const [expanded,setExpanded]=useState<string[]>([]);
 const visible=useMemo(()=>{const q=query.trim().toLowerCase();return customers.map(c=>({...c,orders:q&&![c.name,c.email,c.id].some(v=>v.toLowerCase().includes(q))?c.orders.filter(o=>[o.trackingNumber,o.status,o.driver?.name||"",o.driver?.email||""].some(v=>v.toLowerCase().includes(q))):c.orders})).filter(c=>c.orders.length>0)},[customers,query]);
 const toggle=(id:string)=>setExpanded(s=>s.includes(id)?s.filter(x=>x!==id):[...s,id]);
 return <section style={{display:"grid",gap:14}}>
  <label style={{display:"grid",gap:8}}><strong>Search customer information and messages</strong><input aria-label="Search customers, drivers or tracking numbers" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Customer name, email, account ID, driver or tracking #"/></label>
  <p className="muted" aria-live="polite">{visible.length} customer{visible.length===1?"":"s"} found · {visible.reduce((n,c)=>n+c.orders.length,0)} deliveries</p>
  {visible.length===0?<div className="card">No matching customers or deliveries in the 30-day window.</div>:visible.map(c=><section className="card" key={c.id} style={{margin:0}}>
   <button type="button" onClick={()=>toggle(c.id)} aria-expanded={expanded.includes(c.id)} style={{display:"block",width:"100%",textAlign:"left",cursor:"pointer",border:"none",background:"transparent",color:"inherit",padding:0}}>
    <strong style={{color:"#e5bd50"}}>{expanded.includes(c.id)?"▼":"▶"} {c.name}</strong>
    <span style={{display:"block",marginTop:6}}>{c.email}</span>
    <small className="muted" style={{display:"block",marginTop:4}}>Customer ID: {c.id} · {c.orders.length} deliver{c.orders.length===1?"y":"ies"}</small>
   </button>
   {expanded.includes(c.id)&&<div style={{marginTop:16,display:"grid",gap:12}}>{c.orders.map(o=><details key={o.id} style={{border:"1px solid #594923",borderRadius:12,padding:14,background:"#171717"}}><summary style={{cursor:"pointer",fontWeight:700}}>{o.trackingNumber} · {o.status.replaceAll("_"," ")} · {o.driver?.name||"Unassigned"}</summary><p className="muted" style={{marginBottom:4}}>Driver: {o.driver?.name||"None"} {o.driver?.email?`(${o.driver.email})`:""} · Updated: {new Date(o.updatedAt).toLocaleString()}</p><Chat orderId={o.id} viewerId={viewerId} monitor/></details>)}</div>}
  </section>)}
 </section>;
}
