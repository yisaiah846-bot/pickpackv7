"use client";
import {useEffect,useState} from "react";
type Msg={id:string,body:string,createdAt:string,senderId:string,sender:{name:string,role:string}};
export default function Chat({orderId,viewerId,monitor=false}:{orderId:string,viewerId:string,monitor?:boolean}){
 const [messages,setMessages]=useState<Msg[]>([]),[active,setActive]=useState(false),[body,setBody]=useState(""),[err,setErr]=useState(""),[busy,setBusy]=useState(false);
 async function parseResponse(r:Response){
  const raw=await r.text();let data:any;
  try {data=raw?JSON.parse(raw):null} catch {throw new Error(`Server returned an invalid response (HTTP ${r.status}). Check the terminal for details.`)}
  if(!r.ok)throw new Error(data?.error||`Message request failed (HTTP ${r.status}).`);
  if(!data)throw new Error("Server returned an empty response. Check the terminal for details.");
  return data;
 }
 async function refresh(){try{
  const r=await fetch(`/api/delivery-messages?orderId=${encodeURIComponent(orderId)}`,{cache:"no-store"});
  const j=await parseResponse(r);
  if(!Array.isArray(j.messages))throw new Error("Message response is missing its message list.");
  setMessages(j.messages);setActive(Boolean(j.active));setErr("");
 }catch(e:any){setErr(e instanceof Error?e.message:"Unable to load messages.")}}
 useEffect(()=>{refresh();const id=setInterval(refresh,5000);return()=>clearInterval(id)},[orderId]);
 async function send(e:React.FormEvent){e.preventDefault();if(!body.trim()||busy)return;setBusy(true);setErr("");try{const r=await fetch("/api/delivery-messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({orderId,body})});await parseResponse(r);setBody("");await refresh()}catch(e:any){setErr(e.message)}finally{setBusy(false)}}
 return <div style={{marginTop:12}}><div style={{maxHeight:340,overflowY:"auto",padding:12,background:"#141414",borderRadius:12,border:"1px solid #56451d"}}>{messages.length===0&&!err?<p className="muted">No messages yet.</p>:messages.map(m=><div key={m.id} style={{margin:"10px 0",padding:10,borderRadius:9,background:m.senderId===viewerId?"#433616":"#282828"}}><strong>{m.sender.name} ({m.sender.role.toLowerCase()})</strong><small className="muted" style={{marginLeft:8}}>{new Date(m.createdAt).toLocaleString()}</small><div style={{whiteSpace:"pre-wrap",overflowWrap:"anywhere"}}>{m.body}</div></div>)}</div>{err&&<p role="alert" style={{color:"#ff9d9d"}}>{err}</p>}{monitor?<p className="muted">Read-only monitoring. Messages are visible to authorized admins.</p>:active?<form onSubmit={send} style={{display:"flex",gap:8,marginTop:10}}><input aria-label="Delivery message" value={body} maxLength={2000} onChange={e=>setBody(e.target.value)} placeholder="Message your delivery contact..." style={{flex:1,minWidth:0}}/><button className="btn" disabled={busy||!body.trim()}>Send</button></form>:<p className="muted">Chat is closed. Messages are read-only after delivery, cancellation, or reassignment.</p>}</div>
}
