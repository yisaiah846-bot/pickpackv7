import {session} from "../../lib/auth";
import Link from "next/link";
import {redirect} from "next/navigation";
import ProfileEditor from "./profile-editor";
import ProfileAvatar from "./profile-avatar";
import SignOutButton from "./sign-out-button";
export default async function ProfilePage(){
 const u=await session(); if(!u)redirect("/login");
 const dashboard=u.role==="ADMIN"?"/admin":u.role==="DRIVER"?"/driver":"/dashboard";
 return <main className="wrap" style={{maxWidth:920,paddingBottom:70}}>
  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"16px 0",borderBottom:"1px solid #50401d"}}><strong style={{fontSize:25,color:"#ddb42c"}}>PickPack</strong><Link href="/profile" style={{color:"#ddb42c",display:"inline-flex",alignItems:"center",gap:7}}><svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="9" r="3"/><path d="M5.6 19a7 7 0 0 1 12.8 0"/></svg> Profile</Link></div>
  <section style={{display:"flex",alignItems:"center",gap:20,margin:"25px 0 20px"}}>
   <ProfileAvatar src={`/api/profile/avatar?id=${encodeURIComponent(u.id)}`} size={78}/>
   <div><h1 style={{margin:"0 0 8px"}}>My Profile</h1><span style={{color:"#6fda9a",fontSize:13}}>● Active Account</span><p className="muted" style={{margin:"6px 0 0"}}>Manage your PickPack information</p></div>
  </section>
  <ProfileEditor isDriver={u.role==="DRIVER"} initialName={u.name} email={u.email}/>
  <section className="card" style={{marginTop:18,background:"#222329",borderRadius:14,padding:22}}><h2>Account Settings</h2>
   <p style={{color:"#ddb42c",display:"inline-flex",alignItems:"center",gap:7}}>▣ Change Profile Photo</p><p className="muted">Use the upload control above to replace your picture.</p>
   <hr style={{border:"none",borderTop:"1px solid #454545"}}/>
   <p style={{color:"#ddb42c",display:"inline-flex",alignItems:"center",gap:7}}>♙ Change Password</p><p className="muted">Password changes require a secure verification flow. This control is not yet enabled.</p>
   <hr style={{border:"none",borderTop:"1px solid #454545"}}/>
   <p style={{color:"#ddb42c",display:"inline-flex",alignItems:"center",gap:7}}>◇ Account Security</p><p className="muted">Never share your password or verification codes.</p>
   <SignOutButton role={u.role}/>
  </section>
  <p style={{marginTop:22}}><Link className="ghost" href={dashboard}>← Back to Dashboard</Link></p>
 </main>;
}
