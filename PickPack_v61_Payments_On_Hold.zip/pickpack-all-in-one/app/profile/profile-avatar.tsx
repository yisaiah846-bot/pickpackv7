"use client";
import {useState} from "react";
export default function ProfileAvatar({src,size=78}:{src?:string|null,size?:number}) {
 const [failed,setFailed]=useState(false);
 const showImage=Boolean(src)&&!failed;
 return <span style={{width:size,height:size,borderRadius:"50%",background:"#302b22",border:"2px solid #ddb42c",display:"inline-flex",alignItems:"center",justifyContent:"center",overflow:"hidden",flexShrink:0}}>
 {showImage?<img src={src!} alt="Profile photo" width={size} height={size} onError={()=>setFailed(true)} style={{width:"100%",height:"100%",objectFit:"cover"}}/>:<svg aria-label="Default profile avatar" role="img" width={Math.round(size*.62)} height={Math.round(size*.62)} viewBox="0 0 24 24" fill="none" stroke="#ddb42c" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>}
 </span>;
}
