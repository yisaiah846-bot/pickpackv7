"use client";
import {useState} from "react";
export default function SignOutButton({role}:{role:string}){
 const [busy,setBusy]=useState(false),[error,setError]=useState("");
 async function logout(){setBusy(true);setError("");try{const r=await fetch("/api/auth/logout",{method:"POST"});if(!r.ok)throw new Error("Sign out failed");window.location.assign(role==="ADMIN"?"/admin/login":role==="DRIVER"?"/driver/login":"/login");}catch{setError("Unable to sign out. Please try again.");setBusy(false);}}
 return <div><button type="button" className="ghost" onClick={logout} disabled={busy} style={{border:"1px solid #d4af37",marginTop:12}}>{busy?"Signing out...":"Sign Out"}</button>{error&&<p role="alert">{error}</p>}</div>;
}
