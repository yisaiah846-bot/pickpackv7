"use client";
import {useEffect,useState} from "react";
type Msg={by:"bot"|"you";text:string};
type Ticket={id:string;subject:string;message:string;status:string;adminReply:string|null};
export default function Support(){
 const [messages,setMessages]=useState<Msg[]>([{by:"bot",text:"Hi! I'm the PickPack automated support bot. Ask me about tracking, pricing, addresses, or delivery problems. You can ask for a person anytime."}]);
 const [input,setInput]=useState(""),[busy,setBusy]=useState(false),[tickets,setTickets]=useState<Ticket[]>([]),[error,setError]=useState("");
 async function load(){try{const r=await fetch("/api/support",{cache:"no-store"});if(r.ok)setTickets((await r.json()).tickets)}catch{}}
 useEffect(()=>{void load()},[]);
 async function send(escalate=false){const text=input.trim();if(!text||busy)return;setBusy(true);setError("");if(!escalate)setMessages(m=>[...m,{by:"you",text}]);
 try{const r=await fetch("/api/support/bot",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({message:text,escalate})});const data=await r.json();if(!r.ok)throw Error(data.error||"Support is unavailable");if(escalate)setMessages(m=>[...m,{by:"you",text}]);setMessages(m=>[...m,{by:"bot",text:data.reply}]);setInput("");if(data.escalated)await load();}catch(e){setError(e instanceof Error?e.message:"Please try again")}finally{setBusy(false)}}
 return <main className="wrap"><div className="pill">PICKPACK SUPPORT BOT</div><h1>How can we help?</h1><p className="muted">Automated FAQ support with a direct handoff to an admin. This bot uses predefined answers, not a connected AI model.</p>
 <section className="card"><h2>Chat with PickPack</h2><div role="log" aria-live="polite" style={{maxHeight:390,overflowY:"auto",display:"flex",flexDirection:"column",gap:12,padding:"12px 0"}}>{messages.map((m,i)=><div key={i} style={{alignSelf:m.by==="you"?"flex-end":"flex-start",maxWidth:"85%",background:m.by==="you"?"#554317":"#292b30",color:"white",padding:"12px 15px",borderRadius:14,whiteSpace:"pre-wrap"}}><strong style={{color:"#e2bd44"}}>{m.by==="you"?"You":"PickPack Bot"}</strong><div>{m.text}</div></div>)}</div>
 <form onSubmit={e=>{e.preventDefault();void send()}}><label htmlFor="support-input">Your message</label><textarea id="support-input" rows={3} maxLength={1500} value={input} onChange={e=>setInput(e.target.value)} placeholder="Where is my package?"/><div style={{display:"flex",gap:12,flexWrap:"wrap",marginTop:12}}><button disabled={busy||!input.trim()} type="submit">{busy?"Please wait...":"Ask support bot"}</button><button disabled={busy||!input.trim()} type="button" onClick={()=>void send(true)}>Talk to a person</button></div>{error&&<p role="alert" className="gold">{error}</p>}</form></section>
 <section className="card"><h2>Messages from the support team</h2>{tickets.length===0?<p className="muted">No escalated conversations yet.</p>:tickets.map(t=><article className="order" key={t.id}><strong>{t.subject}</strong> · {t.status}<p>{t.message}</p>{t.adminReply&&<p className="gold">PickPack admin: {t.adminReply}</p>}</article>)}<button type="button" onClick={()=>void load()}>Refresh replies</button></section></main>
}
