"use client";
import {useState} from "react";
export default function CustomerActions({orderId}:{orderId:string}){
 const [busy,setBusy]=useState(false),[message,setMessage]=useState("");
 async function cancel(){if(!confirm("Cancel this demo delivery?"))return;setBusy(true);try{const r=await fetch("/api/demo/cancel",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({orderId})});const j=await r.json();if(!r.ok)throw Error(j.error);location.reload()}catch(e){setMessage((e as Error).message);setBusy(false)}}
 return <><button className="ghost" disabled={busy} onClick={cancel}>Cancel demo</button>{message&&<span className="err"> {message}</span>}</>;
}
