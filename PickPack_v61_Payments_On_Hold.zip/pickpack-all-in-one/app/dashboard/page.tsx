import {session} from "../../lib/auth";
import {db} from "../../lib/db";
import Link from "next/link";

import CustomerActions from "./customer-actions";
export const dynamic="force-dynamic";
const money=(n:number)=>"$"+(n/100).toFixed(2);
export default async function Dashboard(){
 const user=await session();if(!user)return <main className="wrap"><h1>Customer dashboard</h1><p><Link href="/login">Sign in to view your deliveries</Link></p></main>;
 const orders=await db.order.findMany({where:{customerId:user.id},orderBy:{createdAt:"desc"},take:50});
 const active=orders.filter(o=>!["DELIVERED","CANCELLED","RETURNED","REFUNDED"].includes(o.status));
 return <main className="wrap"><div className="pill">PICKPACK · LOCAL TEST ENVIRONMENT</div><h1>Welcome back, {user.name}</h1><p className="muted">Your package deliveries, all in one place.</p><div className="grid"><section className="card"><p className="muted">Total deliveries</p><h2>{orders.length}</h2></section><section className="card"><p className="muted">In progress</p><h2>{active.length}</h2></section><section className="card"><p className="muted">Completed</p><h2>{orders.filter(o=>o.status==="DELIVERED").length}</h2></section></div><p><Link href="/book" className="action-link">+ Book a demo delivery</Link></p><section className="card"><h2>Your deliveries</h2>{orders.length===0?<p className="muted">Nothing here yet. Create a test booking to see how PickPack works.</p>:orders.map(o=><article className="order" key={o.id}><div className="split"><div><span className="pill">{o.status.replaceAll("_"," ")}</span><h3 className="gold">{o.trackingNumber}</h3><p>{o.pickupAddress} → {o.dropoffAddress}</p><p className="muted">{o.service.replaceAll("_"," ")} · {money(o.totalCents)} estimated · Payment not collected</p></div><div className="actions"><Link href={"/track?tracking="+encodeURIComponent(o.trackingNumber)} className="action-link secondary">Track</Link>{["BOOKED","FINDING_DRIVER","DRIVER_ASSIGNED","HEADING_TO_PICKUP","AT_PICKUP"].includes(o.status)&&<CustomerActions orderId={o.id}/>}</div></div></article>)}</section><p className="muted">Simulation only. Booking and driver activity do not authorize real pickup or charge a card.</p></main>
}
