# Tracking map v19 — demo only

The customer tracking page now includes a Leaflet map below the delivery timeline. It uses the existing route-map component and the road routing provider already used by the booking page. The API only exposes map data after its existing account-ownership/admin/driver authorization check.

New demo bookings persist pickup/drop-off coordinates. For older orders with no coordinates, the API attempts exact normalized address matching against `data/addresses.json`. If unmatched, the page explicitly says the coordinates are unavailable. If the road routing service is offline, markers are shown without pretending a straight line is a drivable route. No real GPS or driver movements are simulated as actual location data.

The map tiles and routing service require internet access; demo transactions and dispatch remain unchanged.
