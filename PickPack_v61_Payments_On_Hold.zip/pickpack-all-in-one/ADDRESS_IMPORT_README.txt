PickPack Little Rock address database — 122,223 address points

Source: user-supplied Arkansas GIS Address Points File Geodatabase (SITUS_ADDRESS_PT).
Selection: adr_city or adr_muni equals Little Rock, deduplicated by address + coordinates.

Installation: extract the pickpack-all-in-one folder over your existing project folder.
The ready-to-use data/addresses.json is included; no network import required.
If you run npm.cmd run addresses:import, the included data/arkansas-addresses.csv will rebuild it.

CAUTION: City or municipality labels are not a legal municipal boundary check.
Some records may be outside Little Rock city limits. Route miles and eligibility must be independently validated.
