# PickPack v28 — tracking database repair

## Root cause found
The project uses PostgreSQL (`prisma/schema.prisma`), but the bundled GPS SQL migration used SQLite syntax (`REAL`, `DATETIME`). On PostgreSQL, `DATETIME` is not a valid type, so the `DriverGps` table may never have been created. The tracking API then throws when reading it.

## Required deployment steps
1. Back up your PostgreSQL database.
2. Set `DATABASE_URL` in your hosting environment to your existing PostgreSQL connection.
3. In the project folder, run `npm install`, then `npx prisma db push`, then `npx prisma generate`.
4. Redeploy/restart the Next.js app and test the driver and customer tracking pages.

The included migration SQL is now PostgreSQL-compatible. `prisma db push` is the recommended way to synchronize this demo schema. The tracking endpoint now tolerates a missing GPS table and can still show pickup/drop-off and delivery status, but live GPS requires the table to exist.

This update does not guarantee a fix if the actual problem is database connectivity or a different missing table. Check server logs for the exact error if tracking still fails.
