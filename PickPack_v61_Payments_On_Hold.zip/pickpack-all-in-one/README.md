# PickPack Connected Local Demo — v2

This is a **working local simulation**, not a production delivery service. It builds on your existing PostgreSQL `pickpack` database. The connected test workflow is customer demo booking → owner approves test driver → owner assigns order → driver advances demo statuses → customer sees the status.

## Replace your old project safely (Windows)
1. Stop the current website in PowerShell with `Ctrl+C`.
2. **Back up** the entire existing `pickpack-all-in-one` folder and your PostgreSQL database. Your old `.env` contains private credentials: keep it safe and do not upload it.
3. Extract this ZIP. Copy the **contents** of its `pickpack-all-in-one` folder into your existing folder and choose **Replace files**. The ZIP intentionally does not include `.env`, so your current `.env` stays in place.
4. In PowerShell opened in the existing PickPack folder run:

```powershell
npm.cmd install
npx.cmd prisma validate
npx.cmd prisma generate
npx.cmd prisma db push
```

**Do not approve any database reset or data loss prompt.** If any command fails, stop and ask for help.

5. Create a separate owner account (do NOT use the email of your existing customer account):

```powershell
npm.cmd run admin:setup
```

Enter a new owner email, name and 12+ character password. The script will display a **TOTP authenticator secret**. Add that secret manually to Google Authenticator or Microsoft Authenticator as a time-based account. Store the secret privately. The owner sign-in requires password AND a 6-digit authenticator code. If the account already exists, the setup command will not overwrite it.

6. Start the website:

```powershell
npm.cmd run dev
```

Open `http://localhost:3000`.

## How to test the entire connected workflow
1. Sign in with your existing customer account (or register one).
2. Select **Book** and create a **demo** delivery using example addresses and miles. **No payment is charged**.
3. On Customer dashboard, submit a **test driver application**. For testing, use a second customer account if you want to retain your original account as a customer.
4. Sign out by using the endpoint `POST /api/auth/logout` (or clear localhost cookies / use separate browser profiles). A sign-out button is provided in the navbar in this rebuild.
5. Sign in with your separate owner email, password and authenticator code. Open **Admin**. Approve the test driver application and assign a demo order.
6. Sign in as the approved driver in another browser profile. Open **Driver**. Advance the simulated delivery through its stages.
7. Sign back in as the customer. The status appears on the Customer dashboard. Refresh to see updates.

## What this version actually includes
- Customer registration, sign-in and session cookies (development quality)
- Real PostgreSQL-backed demo orders and status history
- Server-side example price calculation following approved rates
- Demo driver application and admin approval
- Admin account provisioning CLI with TOTP two-factor login
- Owner manual dispatch of demo orders, with an atomic no-double-assignment check
- Max three active assigned orders per demo driver (sequential assignments can race; production requires a transaction-level lock)
- Driver status changes with ownership checks and optimistic state guards
- Customer dashboard and private authenticated tracking
- Premium black-and-gold responsive styling

## What is NOT built / NOT authorized
- Real package acceptance or customer checkout, Stripe authorizations/capture, refunds, payouts, financial ledger
- Authoritative Little Rock municipal GIS boundary, road routing or geocoded quotes; manually entered miles are for simulation only
- Live GPS, dispatch algorithm, real driver offers, optimized routing, navigation, QR/proof verification, background location
- Actual driver license, insurance or identity checks; driver approval here is simulated only
- Email and phone verification, production password recovery, complete MFA recovery, rate limiting, CSRF defenses, advanced session management, security audit
- Emergency dispatch/on-call coverage, AI support, notifications, real tracking link tokens/24h expiry, GPS 30-day retention
- Rewards, bulk CSV, recurring orders, favorite driver, business accounts, claims and disputes
- Public deployment, compliance, insurance, production security testing, operational pilot

**Production protection:** Demo booking, admin mutation, driver mutation and driver application API routes refuse requests in `NODE_ENV=production`. Do not attempt to bypass these restrictions to take real orders. Public deployment requires the missing services, compliance and security work.

**Important:** Admin TOTP secret is stored in the database in this demo. For production, encrypt MFA secrets, provide secure recovery, rate-limit sign-in and implement monitoring. Use a separate password and email for the owner account.

**Existing customer accounts remain intact** if you run the non-destructive schema sync; the schema adds a nullable MFA field. If Prisma warns about data loss, stop.
