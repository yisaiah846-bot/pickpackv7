# PickPack connected demo — local test guide

This is a **simulation only**, not a production courier platform. No payments, routing, identity checks, GPS, or real emergency response are connected.

## Install / start (PowerShell)

1. Back up your existing folder and database. Keep your own `.env` file. Never send screenshots of its contents.
2. `npm.cmd install`
3. `npx.cmd prisma validate`
4. `npx.cmd prisma generate`
5. `npx.cmd prisma db push` — STOP if Prisma warns about reset or data loss.
6. `npm.cmd run demo:check`
7. `npm.cmd run dev`

## Admin access

`npm.cmd run admin:setup` creates a separate owner account. If the email is an existing ADMIN, it requests the **existing owner password** and explicit ROTATE confirmation before rotating credentials and the authenticator setup key. It will not convert a customer into admin. Enter the NEW private setup key into Google/Microsoft Authenticator as **time-based**, then use the **six-digit code** it generates at login. **Never type the setup key into the six-digit code box.**

If your credentials or setup key were exposed in a screenshot, rotate them before testing. The terminal displays passwords while typing; keep your screen private. This local demo's admin recovery is not a production-grade process.

## End-to-end manual test

Use separate browser profiles or log out between roles:

1. Sign in as customer (or register a NEW customer email). Go to **Book**; create a test order with two fictional demo addresses, manual mileage <=25, package weight <=75 lb and declared value <=$500. No real package pickup.
2. Confirm it appears under **Customer** and copy the `PP-DEMO-...` tracking number.
3. Register a **second customer account** for your test driver, then go to **Customer** and submit the demo driver application.
4. Sign out; sign in as owner with authenticator; go to **Admin**, approve the pending test driver and assign the order.
5. Sign out; sign in as the now-approved driver; go to **Driver**. Advance the order through each simulated stage to DELIVERED.
6. Sign in as original customer; verify updated status on **Customer** and **Track**.
7. Verify admin can view completed order. Confirm there were no real charges, maps, GPS or actual dispatch.

## Limits

- Addresses, route miles and overnight surcharge are manual demo inputs, **not validated** by mapping/GIS.
- Demo bookings bypass payment capture intentionally and MUST NOT be used for physical delivery.
- The app's admin 2FA and login flow are development-only; no production security assessment has been completed.
- A passing static check does not prove that all runtime features work. Record any browser or PowerShell errors during the manual test.
