# PickPack v30: mandatory photo proof (demo)

At ARRIVING, drivers must capture/select a JPG, PNG, or WebP photo (max 1.5 MB) and press Complete Delivery With Photo. The server validates the file and transitions ARRIVING -> DELIVERED atomically, recording proof in Order.proofReference and an order event. The normal driver status endpoint cannot mark delivered without photo. Authorized admin, assigned driver and customer can view proof through /api/demo/delivery-proof?orderId=... . GPS and navigation map stop on delivered status.

Note: For demo only, photo data is stored in the existing PostgreSQL order proofReference field. For production, replace this with private object storage, retention controls, and signed access. No Prisma schema changes are needed.
