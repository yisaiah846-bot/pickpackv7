# PickPack v13 — profile and driver verification demo

Added /profile (customer, driver, admin JPEG avatar), driver vehicles (car, motorcycle, bicycle, e-bike, SUV, van), private driver license front/back, insurance, registration uploads, and admin document review on /admin. All data is stored in PostgreSQL and private-uploads/ on the local server. Do NOT use this demo to collect real identity documents until deployment, access control, retention, malware scanning, encryption at rest, rate limiting, security review and regulatory compliance have been completed. Local disk uploads do not persist on many cloud hosts. Documents are only served via authenticated admin endpoint; images are not in public/.

Install: back up project AND database; copy project, retain .env; npm.cmd install; npx.cmd prisma generate; npx.cmd prisma db push (STOP if it proposes destructive changes); npm.cmd run dev. Sign in and visit /profile. Admins review at /admin.

IMPORTANT: This update does not implement a visual route map, automatic verification, automated suspension, license authenticity checks, or real delivery payments. Admin approval of uploaded documents is manual and does not automatically grant delivery eligibility. This remains a simulation, not a production-ready identity verification service.
