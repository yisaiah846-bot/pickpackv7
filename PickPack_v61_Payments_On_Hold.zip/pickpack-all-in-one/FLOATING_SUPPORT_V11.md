# PickPack Floating Support v11

A floating gold Support button is visible in the bottom-right of every page. Clicking it opens the support bot and shows options for tracking, finding addresses, requesting refunds, canceling orders, reporting problems, reporting drivers, and contacting an admin.

This update reuses the existing authenticated /api/support/bot endpoint. Refund, cancellation, driver report, and general report choices create an admin escalation ticket. They do not execute financial transactions, cancel orders, or discipline drivers. Tracking and address help use the existing FAQ bot. The bot is rules-based, not generative AI.

Install: back up your existing project and PostgreSQL database; replace project files while retaining your existing .env. Run npm.cmd install, npx.cmd prisma generate, npm.cmd run dev. Sign in as a customer to send a support message.

Live chat, payment-provider refunds, automatic cancellations, real AI, and live GPS are not implemented in this package.
