# PickPack v53 — provider integration foundations

This build includes Stripe Checkout session creation, Stripe-signed checkout webhook, Stripe Identity session creation, and admin-triggered Twilio SMS incident notification. Existing SMTP verification code is preserved.

## Important limits
- Demo Mode remains enabled. PP-DEMO orders cannot be charged.
- Real payments require a separate non-demo booking flow and live payment lifecycle testing before enabling.
- Stripe Identity session creation is NOT equivalent to driver approval. Verified-result webhook and driver gating are not implemented.
- Emergency SMS is a manual admin trigger only; it is NOT automated escalation or a substitute for emergency services. Verify consent, on-call staffing, and delivery reliability.
- Do not enable production flags without reviewing legal/compliance obligations and performing sandbox tests.
- No provider credentials are included. Never send credentials in chat.

## Setup
1. Run npm install, npx prisma generate, and npm run build.
2. Configure .env from .env.example and use Stripe test keys first.
3. Set STRIPE_WEBHOOK_SECRET from a configured Stripe webhook for checkout.session.completed; point to /api/integrations/stripe-webhook.
4. Set REAL_PAYMENTS_ENABLED=true only after non-demo booking, reconciliation, refund and failure handling are complete.
5. Set IDENTITY_VERIFICATION_ENABLED=true only for controlled Stripe Identity testing.
6. Configure Twilio sender, backup contact and SMS registration; set EMERGENCY_SMS_ENABLED=true only after staff approval and tests.
7. Configure SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, SMTP_FROM for email verification.

API routes: POST /api/integrations/payment-checkout (customer; orderId); POST /api/integrations/driver-identity (driver); POST /api/integrations/emergency-alert (admin; orderId and description).
