# v51: Message retention and readiness

**Not production-ready.** This update adds a secured cleanup endpoint and an admin readiness checklist. It does not implement payment processors, driver background checks, real dispatch, or admin invitations.

1. Back up PostgreSQL.
2. Run `npm.cmd install`, `npx.cmd prisma db push`, `npx.cmd prisma generate`.
3. Configure a random 32+ character `RETENTION_CRON_SECRET` in your server environment. Never expose it in the browser.
4. Schedule an authenticated **POST** to `/api/internal/message-retention` once per day, with header `Authorization: Bearer <RETENTION_CRON_SECRET>`. This endpoint is NOT automatically scheduled by Next.js.
5. Active legal holds can be inserted in `MessageLegalHold` by an authorized database operator using an `orderId` (customer-driver messages) or `driverId` (admin-driver messages). There is not yet an in-app legal-hold interface. Do not enable automatic cleanup until your legal-hold process is approved.
6. Visit `/admin/readiness` to see unfinished work.

The cleanup deletes messages older than 30 days except those covered by an active hold. Retention policy and deletion procedures require legal review before production use.
