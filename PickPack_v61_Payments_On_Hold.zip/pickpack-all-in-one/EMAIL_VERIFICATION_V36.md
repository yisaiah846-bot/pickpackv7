# PickPack v36 Email Verification

- Existing users are grandfathered in using `emailVerificationRequired=false` (the database default). Existing `emailVerified` values are NOT changed. Do not backfill `emailVerified=true`.
- New customer registrations set `emailVerificationRequired=true`, and must enter a 6-digit emailed code before login.
- Codes expire after 10 minutes; 5 attempts maximum; resend cooldown 60 seconds. Admin MFA remains required.
- Set SMTP_HOST, SMTP_PORT (587), SMTP_SECURE (false), SMTP_USER, SMTP_PASSWORD, SMTP_FROM in `.env` for real email delivery. Do not use a demo code in production.
- Install dependencies: `npm.cmd install`. Update DB: `npx.cmd prisma db push` then `npx.cmd prisma generate`.
- Existing accounts retain their current login access. This is enforced via a separate `emailVerificationRequired` flag, NOT by rewriting the `emailVerified` flag.
- The new `/verify-email` page is for new customers. Driver applications and admin invitations need separate onboarding integrations before those account types can be required to verify.
- `db push` is a schema operation; back up the database first. Test on a copy before production use.
