# PickPack v61 — payment hold / website messaging build

## Implemented in this package
- A server-side `PICKPACK_PAYMENTS_RELEASED` gate (defaults to OFF) blocks Stripe Checkout creation, Stripe webhook processing, and driver Stripe Connect onboarding. Never enable it until the payment system has been reviewed and tested.
- Email verification resend endpoint is disabled; the product must provide a secure alternative for password recovery before production release.
- Existing in-website messaging endpoints and UI are retained.

## Not yet completed / must not be represented as production ready
- Demo order/dispatch/GPS routes and demo UI logic are still present. They must be replaced with verified database-backed production workflows.
- Review authentication and authorization on every endpoint; implement durable user messaging notifications, location consent, background checks, and safety procedures.
- Complete password recovery without email, admin MFA recovery, rate limits, abuse prevention and monitoring.
- End-to-end integration tests, migrations, hosted database, storage and Vercel deployment verification are still required.
- Payments, Stripe Connect transfers, refunds and webhooks must remain disabled until audited.

## Deployment
- Set `PICKPACK_PAYMENTS_RELEASED=false`, `REAL_PAYMENTS_ENABLED=false`, `STRIPE_CONNECT_ENABLED=false` in Vercel.
- Never upload `.env` secrets to GitHub.
- Use a hosted database; a local SQLite database is not suitable for Vercel production persistence.
- Extract the ZIP, commit the `pickpack-all-in-one` project contents to the repository root, then configure its database and environment variables.
