-- PostgreSQL-compatible GPS table for PickPack Demo.
-- Previous versions mistakenly used SQLite column types for a PostgreSQL database.
CREATE TABLE IF NOT EXISTS "DriverGps" (
  "orderId" TEXT NOT NULL PRIMARY KEY,
  "driverId" TEXT NOT NULL,
  "lat" DOUBLE PRECISION NOT NULL,
  "lon" DOUBLE PRECISION NOT NULL,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
