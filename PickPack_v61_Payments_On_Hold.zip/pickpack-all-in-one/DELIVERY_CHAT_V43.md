# PickPack v43 Delivery Messages
- Customer and currently assigned driver can message only while status is DRIVER_ASSIGNED, HEADING_TO_PICKUP, AT_PICKUP, PICKED_UP, IN_TRANSIT, ARRIVING.
- Admins can review delivery conversations read-only from /messages.
- Each message is linked to order, sender, and assigned driver at send time. On reassignment, the prior driver loses access; messages from prior driver remain in the admin audit view.
- After delivery/cancellation, sending is rejected server-side; the current pair can view their history.
- Messages poll every five seconds. No email/SMS/push notifications.
- Run `npx.cmd prisma db push` then `npx.cmd prisma generate` after updating. Back up the database first.
- Current ADMIN role can monitor; Dispatch-specific authorization needs a separate staff role/permission implementation.
