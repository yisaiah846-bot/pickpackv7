# PickPack v15 address importer

This replaces the unresponsive Overpass importer with the U.S. Department of Transportation National Address Database ArcGIS feature service. Run `npm.cmd run addresses:import` from the project root, then `npm.cmd run dev`. The script logs progress, times out stalled requests, retries, and does not overwrite existing address data on failure.

**Important:** This ZIP does not contain a populated address database. Import requires network access to the USDOT ArcGIS service. Coverage, fields and access may change. It is not tested against the live endpoint here. If the endpoint blocks access, send the PowerShell output.

Geographic acquisition bounding box is not an official Little Rock city boundary. Booking is still demo-only.
Source: https://www.transportation.gov/mission/open/gis/national-address-database
