# PickPack Dispatch v7 (local demo)

- Renames the manual dispatch panel to Delivery Dispatch Center.
- Adds current, waiting and past delivery views with summary counts.
- Adds an admin-only retry automatic matching action.
- Keeps a manual override for waiting orders.
- Existing demo auto-assignment runs after booking and driver approval.
- All dispatch is local demo only. There is no driver offer/acceptance, GPS, payments, notifications, or physical dispatch.
- The existing auto-assignment chooses the first eligible approved driver with fewer than three active demo jobs, not nearest by GPS.

Install by backing up project/database, copying files into the existing project while keeping .env, running npm.cmd install, npx.cmd prisma validate, npx.cmd prisma generate, then npm.cmd run dev.
