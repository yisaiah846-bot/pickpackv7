# PickPack v31 — Separate sign-in portals

- Customer: `/login` (customer registration only)
- Driver: `/driver/login` (approved drivers only)
- Admin: `/admin/login` (admin only; authenticator required)
- Super Admin: `/admin/admin-accounts` (promote an existing account with its own configured authenticator)

## Setup

1. Set `SUPER_ADMIN_EMAIL` in `.env` to the owner email used with `npm run admin:setup`.
2. Set `AUTH_SECRET` (32+ characters) and `DATABASE_URL`.
3. Run `npm install`, `npx prisma generate`, `npx prisma db push`, and `npm run dev`.
4. Initial admin setup: `npm run admin:setup` in a local development environment. This script intentionally refuses production use.
5. An additional admin must first have an existing account with MFA configured. The Super Admin promotes it via `/admin/admin-accounts`.

The promotion API enforces `SUPER_ADMIN_EMAIL` and requires a valid owner MFA code. There is no public admin registration. This update does not implement admin demotion or MFA enrollment for customer accounts; those still need a secure workflow before additional admins can be promoted. No production deployment or end-to-end browser testing was performed.
