# PickPack production integrations — v52 preparation

This project is **not live-ready**. The existing `/api/demo/*` routes simulate bookings, assignment, payments, and delivery. Do not collect real payments or run physical deliveries through them.

## 1. Card payments and payouts
Select a payment processor (for example Stripe Connect), create business/connected accounts, complete KYC/underwriting, implement hosted checkout/payment intents, idempotent server-side webhook signature verification, refund and dispute handling, payouts and reconciliation. Never accept raw card numbers on your server. Production payments must only be enabled after test-mode and live-mode checks.

## 2. Driver identity and vehicle verification
Select a screening provider, obtain legally appropriate consent, document retention and adverse-action workflows, verify signed provider webhooks, and require explicit approval before granting dispatch eligibility. Do not rely on image upload alone.

## 3. Live email
The existing email verification code uses Nodemailer SMTP. Set `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM` in server-side environment variables. Configure domain SPF/DKIM/DMARC and verify real delivery, bounce handling and rate limits. Never put SMTP secrets in NEXT_PUBLIC_ variables.

## 4. Emergency response
Choose an incident alert provider and staffed escalation contact. Obtain driver consent for location collection, define severe-incident criteria and a 60-second acknowledgment/escalation path. Build retry/deduplication, logging and drills. Do not represent this as emergency services or 911 integration.

## Security and testing
Keep Demo Mode enabled until integrations are complete. Use sandbox provider keys during development. Never put API secrets in a ZIP, browser code, screenshots or chat. Protect all webhooks with signature verification and idempotency; add monitoring, privacy review, backups, role checks and incident response tests. An environment-variable status endpoint at `/api/admin/integration-status` reports **configuration presence only**, never successful integration.
