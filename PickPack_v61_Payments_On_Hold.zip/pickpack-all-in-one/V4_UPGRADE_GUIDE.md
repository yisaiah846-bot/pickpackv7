# PickPack Connected Website v4 — local test release

## What is actually implemented
- Next.js responsive black/gold navigation and pages.
- Customer account login and demo order creation stored in PostgreSQL.
- Customer order history, progress totals, cancel-before-pickup simulation.
- Private tracking by authenticated customer/assigned driver/admin, including event timeline.
- Admin 2FA login, test driver approval and manual demo assignment.
- Driver simulation of delivery status transitions and sample earnings.

## NOT LIVE / NOT READY FOR PUBLIC USERS
Real checkout and Stripe Connect; address autocomplete, official city boundary validation and driving route mileage; GPS; dispatch matching; recipient verification and proof; email/phone verification; real insurance/claims; staffed emergencies; security hardening and load testing. These are mandatory before public launch. The server blocks demo write endpoints in production.

## Install without wiping data
1. Stop Next.js (Ctrl+C); back up the entire project and PostgreSQL database.
2. Replace application files from ZIP, **keep your own .env**, never share it.
3. Run `npm.cmd install`, `npx.cmd prisma validate`, `npx.cmd prisma generate`, `npx.cmd prisma db push`, `npm.cmd run demo:check`, `npm.cmd run dev`.
4. Do not approve any Prisma database reset or data-loss prompt.
5. Test with a separate customer, approved driver and owner account. Rotate previously exposed owner password and authenticator seed securely.

## Test checklist
- Customer signs in; creates a simulated delivery; order appears in dashboard.
- Customer can open Track to view its event history.
- Admin signs in with 6-digit authenticator; approves a driver application; assigns delivery.
- Driver signs in; advances status through Delivered.
- Customer refreshes tracking and sees status history.
- Customer creates another order and cancels before pickup; it cannot be assigned.
- Customer cannot track another customer's order; non-admin cannot enter Admin.

## Important
A functional local demo is **not** a real operational delivery business. Do not accept actual orders or money using this release. Review package vulnerabilities, test all features and complete the outstanding integrations before deployment.
