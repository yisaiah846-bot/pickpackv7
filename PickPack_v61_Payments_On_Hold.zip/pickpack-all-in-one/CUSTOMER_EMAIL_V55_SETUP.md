# PickPack v55 — Customer email verification fix

Customer registration supports Resend or SMTP. It sends a six-digit code that expires in 10 minutes, with a 60-second resend cooldown and five verification attempts. Existing customer accounts remain unchanged.

## Resend setup
1. Create a Resend account at https://resend.com and verify a domain you own for production sending. You do NOT need Google Cloud.
2. Add to your local `.env` (never commit secrets): `RESEND_API_KEY=re_...` and `VERIFICATION_FROM_EMAIL=PickPack <verify@your-verified-domain.com>`.
3. Until you own a domain, Resend's testing sender can generally send only to the email associated with your Resend account. It is NOT suitable for customer signup.
4. Restart the Next.js server, create a NEW test customer, and check the inbox/spam folder. Existing customers are not forced to reverify.
5. If you prefer SMTP, configure `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, and `SMTP_FROM` instead.

## Limits
This update does not supply an email domain, Resend account, API key, or guarantee deliverability. Sending stays unavailable until you configure an approved sender. Do not disable verification to bypass this requirement. Email provider API errors are logged server-side without exposing credentials.
