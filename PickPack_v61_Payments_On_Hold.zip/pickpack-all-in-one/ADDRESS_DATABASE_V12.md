# PickPack v12 — local searchable OSM address index (demo)

## Install
1. Keep your existing `.env` and database; back them up first.
2. Run `npm.cmd install`.
3. Run `npm.cmd run addresses:import` to fetch actual address-tagged OSM objects into `data/addresses.json`. The import can take a while; public Overpass servers may throttle requests. Re-run later if it fails. The ZIP ships with an empty index, not invented addresses.
4. Run `npm.cmd run dev` and open `/book`.

## What works
- Local address autocomplete from imported OSM addresses, no per-search geocoding API.
- Both address choices are backed by coordinates and immutable IDs.
- Driving route distance from OSRM; demo quote from PickPack's pricing.
- The server recomputes mileage before creating a DEMO order; client-supplied mileage is not trusted.

## Not production ready
- OSM address coverage is incomplete and may have wrong city names; verify against authoritative address datasets before launch.
- Bounding box is NOT the official Little Rock city polygon. Municipal boundary validation is not implemented.
- `router.project-osrm.org` is a public demo server with no SLA, not suitable for production. Configure `PICKPACK_ROUTING_URL` to your own OSRM server or permitted hosted router.
- No rendered road map or driver GPS tracking in v12; route geometry is available from `/api/route-preview` for later mapping.
- Existing site remains demo-only: no real charges or bookings.
- OSM data attribution and license (ODbL): https://www.openstreetmap.org/copyright . Verify provider usage policies before production.
