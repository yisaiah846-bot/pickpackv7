# PickPack automatic demo v5

This is a **local simulation**, not a production delivery website.

## Automatic in this update
- When a customer creates a demo booking, the system attempts to assign it to an already approved demo driver.
- When an admin approves a demo driver, waiting demo bookings are automatically considered for assignment.
- Each demo driver is limited to 3 active orders, and assignment uses a database transaction to avoid double-assignment.
- Demo orders retain explicit DEMO_NO_PAYMENT status. No real payments, physical dispatch, driver consent, route verification, GPS or emergency services are performed.
- Existing admin manual assignment remains available when automatic matching cannot find an eligible driver.

## Not yet automatic or live
Real booking and capture, driver offer acceptance, GPS/traffic-aware matching, SMS/email, payout processing, real-world custody, emergency escalation, and production-safe deployment all require further integrations and tests. Do not use this demo to send real packages.

## Installation
1. Stop local server (Ctrl+C) and back up the existing project and PostgreSQL database.
2. Extract and copy application files; **retain your private .env**. Never copy secrets into screenshots.
3. Run `npm.cmd install`, `npx.cmd prisma validate`, `npx.cmd prisma generate`, then `npm.cmd run dev`.
4. Test with an approved driver and a separate customer. New demo orders should show DRIVER_ASSIGNED automatically; if none is approved, they remain FINDING_DRIVER until approval.

**Security:** Any password and MFA setup key previously shared in screenshots must be rotated. Audit dependency vulnerabilities before public deployment.
