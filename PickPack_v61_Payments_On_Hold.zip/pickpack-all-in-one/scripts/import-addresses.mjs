// PickPack v16: offline import of real address points from CSV or GeoJSON.
// Put a licensed, real address dataset at data/arkansas-addresses.csv or .geojson.
// CSV needs lat/lon and either a full address or house number + street.
import fs from 'node:fs/promises';
import path from 'node:path';
const dataDir=path.join(process.cwd(),'data');
const choices=['arkansas-addresses.geojson','arkansas-addresses.json','arkansas-addresses.csv'];
const source=process.env.PICKPACK_ADDRESS_FILE || (await Promise.all(choices.map(async x=>({x,exists:await fs.access(path.join(dataDir,x)).then(()=>true,()=>false)})))).find(x=>x.exists)?.x;
if(!source){console.error('No real address source found. Place a CSV or GeoJSON file in data/ named arkansas-addresses.csv or arkansas-addresses.geojson.');console.error('You can also set $env:PICKPACK_ADDRESS_FILE to the full path of a downloaded address dataset.');process.exit(1)}
const file=path.isAbsolute(source)?source:path.join(dataDir,source);
console.log('Reading real address records from:',file);
const raw=await fs.readFile(file,'utf8');
function parseCSV(s){const out=[];let row=[],field='',quoted=false;for(let i=0;i<s.length;i++){const c=s[i];if(c==='"'){if(quoted&&s[i+1]==='"'){field+='"';i++}else quoted=!quoted}else if(c===','&&!quoted){row.push(field);field=''}else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&s[i+1]==='\n')i++;row.push(field);if(row.some(v=>v.trim()))out.push(row);row=[];field=''}else field+=c}row.push(field);if(row.some(v=>v.trim()))out.push(row);const header=(out.shift()||[]).map(x=>x.trim().replace(/^\uFEFF/,''));return out.map(a=>Object.fromEntries(header.map((h,i)=>[h,a[i]||''])))}
let records;
if(file.toLowerCase().endsWith('.csv'))records=parseCSV(raw);
else {const obj=JSON.parse(raw);records=Array.isArray(obj)?obj:(obj.features||[]).map(f=>({...f.properties,__coordinates:f.geometry?.coordinates}))}
const get=(o,...keys)=>{const map=new Map(Object.keys(o).map(k=>[k.toLowerCase().replace(/[^a-z0-9]/g,''),k]));for(const k of keys){const v=o[map.get(k.toLowerCase().replace(/[^a-z0-9]/g,''))];if(v!==undefined&&v!==null&&String(v).trim())return v}return ''};
const rows=[],seen=new Set();let invalid=0;
for(const a of records){const c=a.__coordinates;const lat=Number(c?.[1]??get(a,'latitude','lat','y'));const lon=Number(c?.[0]??get(a,'longitude','lon','lng','long','x'));if(!Number.isFinite(lat)||!Number.isFinite(lon)||lat<33||lat>37||lon< -95||lon> -89){invalid++;continue}
 const house=String(get(a,'number','housenumber','house_number','add_number','addressnumber')).trim();const street=String(get(a,'street','streetname','street_name','full_street_name','fullstreetname')).trim();
 const address=String(get(a,'fulladdress','full_address','address','siteaddress','site_address','formattedaddress')).trim()||[house,street].filter(Boolean).join(' ');
 if(!address||!/[0-9]/.test(address)){invalid++;continue}
 const city=String(get(a,'city','municipality','post_comm','postalcity')).trim()||'Arkansas';const zip=String(get(a,'zip','zipcode','postcode','post_code','postalcode')).trim();
 const label=address+(address.toLowerCase().includes(', ar')?'':`, ${city}, AR${zip?' '+zip:''}`);
 const key=`${label.toLowerCase()}|${lat.toFixed(6)}|${lon.toFixed(6)}`;if(seen.has(key))continue;seen.add(key);rows.push({id:'local-'+rows.length,label,lat,lon});
}
if(!rows.length)throw Error(`No valid address records found (${invalid} rejected). Existing addresses.json was NOT overwritten. Check CSV column names and coordinates.`);
rows.sort((a,b)=>a.label.localeCompare(b.label));await fs.mkdir(dataDir,{recursive:true});const dest=path.join(dataDir,'addresses.json');await fs.writeFile(dest+'.tmp',JSON.stringify(rows));await fs.rename(dest+'.tmp',dest);console.log(`SUCCESS: Imported ${rows.length} real address points (${invalid} invalid rows skipped).`);console.log('Note: municipal eligibility and driving routes must be validated separately.');
