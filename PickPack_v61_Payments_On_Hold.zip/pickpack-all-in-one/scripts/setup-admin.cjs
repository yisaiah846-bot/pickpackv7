const {PrismaClient}=require('@prisma/client');
const bcrypt=require('bcryptjs');
const {authenticator}=require('otplib');
const readline=require('readline');
const db=new PrismaClient();
const rl=readline.createInterface({input:process.stdin,output:process.stdout});
const ask=q=>new Promise(resolve=>rl.question(q,resolve));
(async()=>{try{
 if(process.env.NODE_ENV==='production')throw Error('Local demo setup only; disabled in production');
 const email=(await ask('Owner email: ')).trim().toLowerCase();
 const name=(await ask('Owner name: ')).trim();
 const password=await ask('New owner password (12+ characters; visible while typing; keep screen private): ');
 if(!/^\S+@\S+\.\S+$/.test(email)||name.length<2||password.length<12)throw Error('Valid email, name, and 12+ character password required');
 const existing=await db.user.findUnique({where:{email}});
 if(existing&&existing.role!=='ADMIN')throw Error('That email is a customer account. Use a DIFFERENT owner email.');
 if(existing){
   const current=await ask('Existing owner password (visible while typing): ');
   if(!(await bcrypt.compare(current,existing.passwordHash)))throw Error('Current owner password incorrect. No changes made.');
   const confirm=(await ask('Rotate existing admin password AND authenticator secret? Type ROTATE: ')).trim();
   if(confirm!=='ROTATE')throw Error('Cancelled. No changes made.');
 }
 const secret=authenticator.generateSecret();
 const data={name,passwordHash:await bcrypt.hash(password,12),mfaSecret:secret};
 if(existing)await db.user.update({where:{id:existing.id},data});
 else await db.user.create({data:{email,role:'ADMIN',...data}});
 console.log('\nADMIN '+(existing?'CREDENTIALS ROTATED':'CREATED')+'. Add the following secret as a TIME-BASED key to Google/Microsoft Authenticator.');
 console.log('PRIVATE SETUP KEY:',secret);
 console.log('This key is NOT a login code. Your authenticator app generates the six-digit login code.');
 console.log('Keep the setup key private; never send screenshots of it or your password.');
 console.log('Restart the development server after rotation and sign in with your new credentials.');
}catch(e){console.error('Setup failed:',e.message);process.exitCode=1}finally{rl.close();await db.$disconnect()}})();
