const fs=require('fs');
const required=['app/api/demo/orders/route.ts','app/api/demo/admin/route.ts','app/api/demo/driver/route.ts','app/api/demo/apply/route.ts','app/api/auth/login/route.ts','app/api/track/route.ts','prisma/schema.prisma'];
for(const f of required){if(!fs.existsSync(f))throw Error('Missing '+f);console.log('OK',f)}
const schema=fs.readFileSync('prisma/schema.prisma','utf8');
for(const m of ['User','Order','OrderEvent','DriverApplication','AuditLog'])if(!schema.includes('model '+m+' {'))throw Error('Missing model '+m);
const pricing=fs.readFileSync('lib/pricing.ts','utf8');
for(const token of ['SCHEDULED:[599,125]','SAME_DAY:[799,150]','EXPRESS:[1299,200]'])if(!pricing.includes(token))throw Error('Pricing mismatch '+token);
console.log('Static demo checks passed. Run prisma validate and next build separately; full role workflow requires a running database.');
