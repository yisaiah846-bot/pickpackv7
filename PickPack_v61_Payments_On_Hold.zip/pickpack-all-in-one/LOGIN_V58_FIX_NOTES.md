# PickPack v58 — All Sign-in Portals

Customer /login: registration and login without customer email verification.
Driver /driver/login: only accounts with role DRIVER can enter. Customer accounts must apply at /become-driver and be approved; role is never changed just to permit login.
Admin /admin/login: only ADMIN role and valid existing authenticator MFA. MFA has not been bypassed.

Fixes: actionable wrong-portal links, input validation, non-JSON responses, clearer server errors, button loading state, and redirect to correct dashboard after success.

Before starting: check AUTH_SECRET is configured with 32+ characters; verify database connection and existing users. Run npm install, npx prisma generate, npm run build, npm run dev.
Never share passwords, Stripe keys, or AUTH_SECRET. This package has not been end-to-end tested against your production database.
