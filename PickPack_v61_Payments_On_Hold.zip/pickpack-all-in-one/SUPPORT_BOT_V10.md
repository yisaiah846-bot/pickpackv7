# PickPack Support Bot v10

Replaces the customer support form with an interactive rule-based FAQ chat. The bot answers common questions about tracking, pricing, address guidance, and refunds. The **Talk to a person** button saves a support ticket in PostgreSQL and shows admin replies under the chat. The admin dashboard displays escalated requests.

This is **not a generative AI integration**. No external model API or paid service is configured. No customer financial or delivery changes are performed by the bot.

## Installation
Back up your current application and PostgreSQL database, keep your own `.env`, run `npm.cmd install`, `npx.cmd prisma generate`, then `npm.cmd run dev`. Visit `/support`. Sign in to submit questions. Test escalation and admin reply with separate accounts.
