import {session} from "./auth";
export async function requireAdmin(){const user=await session();return user?.role==="ADMIN"?user:null}
export const configured=(...names:string[])=>names.every(n=>!!process.env[n]?.trim());
