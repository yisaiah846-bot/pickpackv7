export type ServiceName = "SCHEDULED"|"SAME_DAY"|"EXPRESS";
const tariffs:Record<ServiceName,[number,number]> = {SCHEDULED:[599,125],SAME_DAY:[799,150],EXPRESS:[1299,200]};
export function quote(input:{service:ServiceName,miles:number,weight:number,overnight:boolean,tipCents?:number}) {
 const {service,miles,weight,overnight}=input;
 if(!Number.isFinite(miles)||miles<=0||miles>25) throw new Error("Driving route must be over 0 and at most 25 miles");
 if(!Number.isFinite(weight)||weight<=0||weight>75) throw new Error("Package weight must be over 0 and at most 75 lb");
 const [base,perMile]=tariffs[service];
 const baseMileageCents=base+Math.round(perMile*miles);
 const weightFeeCents=weight<=10?0:weight<=25?300:weight<=50?700:1500;
 const overnightFeeCents=overnight?500:0;
 const tipCents=input.tipCents??0;
 if(!Number.isSafeInteger(tipCents)||tipCents<0||tipCents>100000) throw new Error("Invalid tip");
 const totalCents=baseMileageCents+weightFeeCents+overnightFeeCents+tipCents;
 const driverEarningsCents=Math.round(baseMileageCents*.65)+Math.round(weightFeeCents*.5)+Math.round(overnightFeeCents*.65)+tipCents;
 return {baseMileageCents,weightFeeCents,overnightFeeCents,tipCents,totalCents,driverEarningsCents,companyGrossCents:totalCents-driverEarningsCents};
}
