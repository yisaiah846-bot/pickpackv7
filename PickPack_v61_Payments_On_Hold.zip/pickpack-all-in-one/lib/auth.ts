import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";
import { db } from "./db";
import type { Role } from "@prisma/client";
const secret = () => {
 const s = process.env.AUTH_SECRET;
 if (!s || s.length < 32) throw new Error("AUTH_SECRET must be at least 32 characters");
 return new TextEncoder().encode(s);
};
export async function session() {
 const token = (await cookies()).get("pickpack_session")?.value;
 if (!token) return null;
 try {
  const { payload } = await jwtVerify(token, secret());
  if (typeof payload.sub !== "string") return null;
  return await db.user.findUnique({where:{id:payload.sub},select:{id:true,email:true,name:true,role:true,emailVerified:true,phoneVerified:true,stripeConnectAccountId:true}});
 } catch { return null; }
}
export async function issueSession(id:string) {
 const jwt = await new SignJWT({}).setProtectedHeader({alg:"HS256"}).setSubject(id).setIssuedAt().setExpirationTime("7d").sign(secret());
 (await cookies()).set("pickpack_session",jwt,{httpOnly:true,secure:process.env.NODE_ENV==="production",sameSite:"lax",path:"/",maxAge:604800});
}
export function allowed(role:Role, roles:Role[]) {return roles.includes(role);}
