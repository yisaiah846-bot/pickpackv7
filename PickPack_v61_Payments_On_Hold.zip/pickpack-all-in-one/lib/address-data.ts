import fs from 'node:fs';import path from 'node:path';
export type Address={id:string;label:string;lat:number;lon:number};
let cache:Address[]|undefined;let cachedMtime=0;
export function addresses():Address[]{const file=path.join(process.cwd(),'data','addresses.json');try{const mtime=fs.statSync(file).mtimeMs;if(cache&&mtime===cachedMtime)return cache;const raw=JSON.parse(fs.readFileSync(file,'utf8'));cache=Array.isArray(raw)?raw.filter((a:any)=>typeof a.id==='string'&&typeof a.label==='string'&&Number.isFinite(a.lat)&&Number.isFinite(a.lon)):[];cachedMtime=mtime;return cache;}catch{return []}}
export function findAddress(id:string){return addresses().find(a=>a.id===id)}
