import {NextResponse} from "next/server";
export function demoOnly(){return process.env.NODE_ENV==="production"?NextResponse.json({error:"Demo operations are disabled in production"},{status:403}):null}
export function money(n:number){return "$"+(n/100).toFixed(2)}
