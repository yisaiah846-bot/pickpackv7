import {findAddress} from './address-data';
export async function calculateRoute(pickupId:string,dropoffId:string){const a=findAddress(pickupId),b=findAddress(dropoffId);if(!a||!b)throw Error('Select a verified suggestion for both addresses. Run the address import if suggestions are empty.');
// Bounding box is an initial guard, not an official Little Rock municipal boundary check.
const bbox=(p:typeof a)=>p.lat>=34.62&&p.lat<=34.88&&p.lon>=-92.50&&p.lon<=-92.12;
if(!bbox(a)||!bbox(b))throw Error('Address outside supported preliminary search area');
const base=process.env.PICKPACK_ROUTING_URL||'https://router.project-osrm.org';
const url=`${base}/route/v1/driving/${a.lon},${a.lat};${b.lon},${b.lat}?overview=full&geometries=geojson`;
const r=await fetch(url,{cache:'no-store',signal:AbortSignal.timeout(12000)});if(!r.ok)throw Error('Routing service unavailable. Try again later.');
const data=await r.json();const route=data.routes?.[0];if(data.code!=='Ok'||!route||!Number.isFinite(route.distance))throw Error('No drivable route found');
const miles=route.distance/1609.344;if(miles<=0||miles>25)throw Error('Driving route must be at most 25 miles');
return {pickup:a,dropoff:b,miles:Number(miles.toFixed(2)),durationMinutes:Math.round(route.duration/60),geometry:route.geometry};}
