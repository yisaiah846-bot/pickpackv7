import {randomInt} from "node:crypto";
import bcrypt from "bcryptjs";
import nodemailer from "nodemailer";
import {db} from "./db";

export function emailProviderConfigured(){
 return Boolean((process.env.RESEND_API_KEY&&process.env.VERIFICATION_FROM_EMAIL)||(process.env.SMTP_HOST&&process.env.SMTP_USER&&process.env.SMTP_PASSWORD&&process.env.SMTP_FROM));
}
async function deliverCode(email:string,code:string){
 const from=process.env.VERIFICATION_FROM_EMAIL;
 const text=`Your PickPack verification code is ${code}. It expires in 10 minutes. If you did not request this, ignore this email.`;
 if(process.env.RESEND_API_KEY&&from){
  const response=await fetch("https://api.resend.com/emails",{method:"POST",headers:{Authorization:`Bearer ${process.env.RESEND_API_KEY}`,"Content-Type":"application/json"},body:JSON.stringify({from,to:[email],subject:"Verify your PickPack email",text}),cache:"no-store"});
  if(!response.ok){console.error("PickPack email provider failed",response.status);throw new Error("Verification email could not be delivered. Contact support.")}
  return;
 }
 const smtpHost=process.env.SMTP_HOST,smtpUser=process.env.SMTP_USER,smtpPass=process.env.SMTP_PASSWORD,smtpFrom=process.env.SMTP_FROM;
 if(!smtpHost||!smtpUser||!smtpPass||!smtpFrom)throw new Error("Email provider is not configured. Contact support.");
 const transporter=nodemailer.createTransport({host:smtpHost,port:Number(process.env.SMTP_PORT||587),secure:process.env.SMTP_SECURE==="true",auth:{user:smtpUser,pass:smtpPass}});
 await transporter.sendMail({from:smtpFrom,to:email,subject:"Verify your PickPack email",text});
}
export async function sendVerificationCode(userId:string,email:string){
 if(!emailProviderConfigured())throw new Error("Email verification is not configured yet. Contact support.");
 const user=await db.user.findUnique({where:{id:userId}});
 if(!user||!user.emailVerificationRequired||user.emailVerified)throw new Error("Email verification not required");
 if(user.emailVerificationSentAt&&Date.now()-user.emailVerificationSentAt.getTime()<60000)throw new Error("Wait 60 seconds before requesting another code");
 const code=String(randomInt(0,1000000)).padStart(6,"0");
 // Persist the code before delivery to avoid an email arriving with a code that cannot be verified.
 await db.user.update({where:{id:userId},data:{emailVerificationCodeHash:await bcrypt.hash(code,10),emailVerificationExpiresAt:new Date(Date.now()+600000),emailVerificationSentAt:new Date(),emailVerificationAttempts:0}});
 await deliverCode(email,code);
}
