import {db} from "./db";

// LOCAL DEMO ONLY. Never dispatch real packages or assume payment succeeded.
// First available approved driver with fewer than three active demo orders.
export async function autoAssignDemoOrders() {
  if (process.env.NODE_ENV === "production") return {assigned:0};
  const waiting = await db.order.findMany({
    where:{status:"FINDING_DRIVER",driverId:null,paymentStatus:"DEMO_NO_PAYMENT"},
    orderBy:{createdAt:"asc"},take:100,select:{id:true}
  });
  let assigned=0;
  for (const order of waiting) {
    const drivers=await db.user.findMany({where:{role:"DRIVER"},select:{id:true},orderBy:{createdAt:"asc"}});
    for(const driver of drivers){
      const hold=await db.driverDiscipline.findFirst({where:{driverId:driver.id,OR:[{action:"DEACTIVATE"},{action:"SUSPEND",OR:[{suspensionEndsAt:null},{suspensionEndsAt:{gt:new Date()}}]}]},orderBy:{createdAt:"desc"}});
      const restore=await db.driverDiscipline.findFirst({where:{driverId:driver.id,action:"RESTORE"},orderBy:{createdAt:"desc"}});
      if(hold && (!restore || restore.createdAt<=hold.createdAt))continue;
      try {
        const success=await db.$transaction(async tx=>{
          // Transaction serializable to avoid assigning beyond capacity during concurrent requests.
          const active=await tx.order.count({where:{driverId:driver.id,status:{notIn:["DELIVERED","CANCELLED","RETURNED","REFUNDED"]}}});
          if(active>=3)return false;
          const updated=await tx.order.updateMany({where:{id:order.id,status:"FINDING_DRIVER",driverId:null,paymentStatus:"DEMO_NO_PAYMENT"},data:{driverId:driver.id,status:"DRIVER_ASSIGNED"}});
          if(updated.count!==1)return false;
          await tx.orderEvent.create({data:{orderId:order.id,actorId:driver.id,status:"DRIVER_ASSIGNED",note:"AUTO-ASSIGNED FOR LOCAL DEMO ONLY. No driver offer acceptance, verified route or payment."}});
          await tx.auditLog.create({data:{actorId:driver.id,action:"DEMO_AUTO_ASSIGNED",subjectId:order.id}});
          return true;
        },{isolationLevel:"Serializable"});
        if(success){assigned++;break;}
      }catch(e){console.error("Demo auto-assignment retry on next request",e);}
    }
  }
  return {assigned};
}
