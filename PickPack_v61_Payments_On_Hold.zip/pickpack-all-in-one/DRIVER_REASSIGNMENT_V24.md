# Driver cancellation and pickup reassignment (Demo only)

Drivers can cancel an assigned pickup only in DRIVER_ASSIGNED, HEADING_TO_PICKUP or AT_PICKUP. The API atomically removes driver assignment and returns the order to FINDING_DRIVER. Another approved driver can accept the same tracking number from Available Pickups. Atomic updateMany prevents simultaneous double acceptance. Driver cancellation after PICKED_UP is rejected server-side. Cancellation/acceptance creates order events and audit entries. No second payment is created.

This is a local demo. GPS visibility, browser permission, customer notifications and production deployment require separate end-to-end verification.
