# PickPack v50 — Dispatch ↔ Driver message database fix

The `StaffDriverMessage` table was introduced in v48. If your database was not updated, the Dispatch → Driver Messages panel shows a load error. The app cannot create database tables automatically from the browser.

## Fix on Windows PowerShell

1. Stop Next.js (Ctrl+C).
2. In the extracted `pickpack-all-in-one` folder, confirm your `.env` has the correct PostgreSQL `DATABASE_URL`.
3. Run:

```powershell
npm.cmd install
npx.cmd prisma db push
npx.cmd prisma generate
npm.cmd run dev
```

4. Reload `/messages` and open the driver conversation.

**Important:** `prisma db push` changes your database schema. Back up your database before running it against important data. This should not delete existing delivery records, but review Prisma's output and do not accept a data-loss warning without checking.

## If it still fails

Copy the exact error shown on the Messages page and the matching `[PickPack] staff-driver-messages` error from your Next.js terminal. The API now reports missing tables (`P2021`), missing columns (`P2022`), and stale Prisma client errors separately.

This version does not bypass authentication or move messages into local browser storage. Admins can contact registered drivers; drivers can reply. The message history displayed is limited to 30 days.
