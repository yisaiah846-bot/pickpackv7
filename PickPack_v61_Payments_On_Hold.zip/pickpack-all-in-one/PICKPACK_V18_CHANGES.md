# PickPack v18 — integrated demo update

- Full v17 project preserved, including Prisma, APIs, address database, dispatch, booking and support.
- Driver signup moved to `/become-driver` and removed from `/dashboard`.
- Dedicated admin category at `/admin/driver-applications` with applicant names, contact and approval.
- Driver access still requires admin approval.
- Simulation mode retained. No real payments or driver screening.
- Signup collects demo-only vehicle and contact information. Do not enter real identity documents.

## Run
Follow the original README: configure `.env`, install dependencies, run Prisma setup and `npm run dev`.
